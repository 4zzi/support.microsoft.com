import { promotionLogger } from './PromotionLogging';
import type { ApplicationInsights, Behavior } from '@microsoft/1ds-analytics-web-js';

declare global {
	interface Window {
		analytics?: ApplicationInsights;
		oneDS: {
			Behavior: typeof Behavior;
		};
		initPromotionLogger: () => void;
	}
}

window.initPromotionLogger = () => {
	promotionLogger();
}
