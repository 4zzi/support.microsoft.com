import { DefaultContainerName } from '../../constants';
import { IDataTag } from '../PromotionLogging.types';

const formattedTagValue = (tagValue: string | undefined): string => tagValue ? tagValue.replace('|', ' ') : '';

export const initializeDataTag = (banner: HTMLElement, defaultValue: string): IDataTag => {
	const bannerArea: string = banner.dataset.biArea || defaultValue;
	const bannerCampaignId: string = banner.dataset.biCampaignid || '';
	const bannerId: string = banner.dataset.biId || defaultValue;
	const bannerScenario: string = banner.dataset.biScn || defaultValue;
	let bannerContent: string = [
		formattedTagValue(banner.dataset.biTitle),
		formattedTagValue(banner.dataset.biSubtext),
		formattedTagValue(banner.dataset.biButton),
	].join('|');

	if (banner.dataset.biLink) {
		bannerContent += `|${formattedTagValue(banner.dataset.biLink)}`;
	}

	return {
		content: {
			areaName: bannerArea,
			campaignId: bannerCampaignId,
			containerName: DefaultContainerName,
			contentId: bannerId,
			scn: bannerScenario,
			contentName: bannerContent,
		},
	};
};
