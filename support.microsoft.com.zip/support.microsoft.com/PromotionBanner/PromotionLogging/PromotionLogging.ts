import {
	ucsStaticBanners,
} from '../constants';
import {
	emitClickAction,
	emitDismissAction,
	emitContentUpdate,
} from './eventEmitters';
import { initializeDataTag } from './utils';

export const promotionLogger = () => {
	let dismissedBannerSet: Object = {};

	for (const banner of ucsStaticBanners) {
		const currentBannerElement = document.querySelector<HTMLElement>(banner.element);

		if (!currentBannerElement) {
			continue;
		}

		const dataTag = initializeDataTag(currentBannerElement, banner.element);

		const bannerClickSelectors = document.querySelectorAll<HTMLElement>(banner.clickSelector)

		for (let i = 0; i < bannerClickSelectors.length; i++) {
			const bannerClickSelector = bannerClickSelectors[i];
			bannerClickSelector.addEventListener('click', event => {
				emitClickAction(bannerClickSelector, dataTag);
			})
		}

		const bannerDismissSelectors = document.querySelectorAll<HTMLElement>(banner.dismissSelector);

		for (let i = 0; i < bannerDismissSelectors.length; i++) {
			const bannerDismissSelector = bannerDismissSelectors[i];
			bannerDismissSelector.addEventListener('click', event => {
				const bannerId = dataTag.content.contentId;
				dismissedBannerSet[bannerId] = emitDismissAction(
					bannerDismissSelector,
					dataTag,
					bannerId,
					dismissedBannerSet
				);
			});

		}

		emitContentUpdate(dataTag);
	}
};
