import { IDataTag } from '../PromotionLogging.types';
import { ClickActionTypeID } from '../../constants';

export const emitDismissAction = (
	dismissElement: HTMLElement,
	dataTag: IDataTag,
	bannerId: string,
	dismissedBannerSet: {}
) => {
	if (!dismissElement) {
		return;
	}

	const analytics = window.analytics;

	//BUG: We are seeing a bug where on a small set of clients this code gets stuck in a loop, causing a lot of dismissed actions for a single click
	if (!dismissedBannerSet[bannerId]) {
		dismissedBannerSet[bannerId] = true;

		if (analytics) {
			const newBannerId = `${bannerId}-dismiss`;
			const contentTags = { ...dataTag.content, contentId: newBannerId };

			const ondsTagSet = {
				actionType: ClickActionTypeID,
				behavior: window.oneDS.Behavior.HIDE,
				content: contentTags,
			};

			analytics.capturePageAction(dismissElement, ondsTagSet, null);
		}

		return true;
	}

	return true;
};
