import { IDataTag } from '../PromotionLogging.types';
import { ClickActionTypeID, InvalidHref } from '../../constants';

export const emitClickAction = (clickElement: HTMLElement, dataTag: IDataTag) => {
	const analytics = window.analytics;

	if (!clickElement) {
		return;
	}

	const contentTags = { ...dataTag.content, slot: clickElement.dataset.biSlot ?? '' };

	if (analytics) {
		const tagSet = {
			behavior: window.oneDS?.Behavior.UNDEFINED,
			actionType: ClickActionTypeID,
			targetUri: clickElement.getAttribute('href') ?? InvalidHref,
			content: contentTags
		};

		analytics.capturePageAction(clickElement, tagSet, null);
	}
};
