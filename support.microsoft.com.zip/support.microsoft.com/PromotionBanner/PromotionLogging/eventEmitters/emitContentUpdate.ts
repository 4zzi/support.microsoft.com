import { IDataTag } from '../PromotionLogging.types';

export const emitContentUpdate = (dataTag: IDataTag) => {
	const analytics = window.analytics;

	if (analytics) {
		analytics.captureContentUpdate({
			...dataTag,
			behavior: window.oneDS.Behavior.IMPRESSION,
		}, null);
	}
};
