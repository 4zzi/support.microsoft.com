export interface IDataTag {
	content: {
		areaName: string;
		contentId: string;
		scn: string;
		containerName: string;
		contentName: string;
		campaignId: string;
	};
}

export enum ElementReference {
	PromotionBanner = '.PromotionBanner',
	TopPageBanner = '.TopPageBanner',
	AboveUhfBanner = '.AboveUhfBanner',
	RailBanner = '.RailBanner',
	NpsRailBanner = '.NpsRailBanner',
	RailSecondaryCtaBanner = '.RailSecondaryCtaBanner',
	CopilotRailBanner = '.CopilotRailBanner',
}

export interface IBannerLoggingData {
	dismissSelector?: string;
	clickSelector?: string;
	element?: string;
}
