import type { IBannerLoggingData } from '../PromotionLogging/PromotionLogging.types';
import { ElementReference } from '../PromotionLogging/PromotionLogging.types';

export const ucsStaticBanners: IBannerLoggingData[] = [
	{
		dismissSelector: null,
		clickSelector: '#ucsTopBannerButtonLink',
		element: ElementReference.PromotionBanner,
	},
	{
		dismissSelector: '#top-banner-dismiss-button',
		clickSelector: '#ucsTopBannerButtonLink',
		element: ElementReference.TopPageBanner,
	},
	{
		dismissSelector: '#uhf-banner-close',
		clickSelector: '#upgradeUhfBannerButton',
		element: ElementReference.AboveUhfBanner,
	},
	{
		dismissSelector: '#rail-banner-dismiss-button',
		clickSelector: '#rail-banner-button',
		element: ElementReference.RailBanner,
	},
	{
		dismissSelector: '#nps-rail-close',
		clickSelector: '#nps-rail-link',
		element: ElementReference.NpsRailBanner,
	},
	{
		dismissSelector: '#rail-banner-dismiss-button',
		clickSelector: '#rail-banner-button, #rail-banner-button-secondary',
		element: ElementReference.RailSecondaryCtaBanner,
	},
	{
		dismissSelector: '#rail-banner-dismiss-button',
		clickSelector: '#rail-banner-button, #rail-banner-button-secondary, #rail-banner-button-tertiary',
		element: ElementReference.CopilotRailBanner
	},
];

export const DefaultContainerName = 'growth_placement';

export const ClickActionTypeID = 'CL';

export const InvalidHref = 'href not found';
