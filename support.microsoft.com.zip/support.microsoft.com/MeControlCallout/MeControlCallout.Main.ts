// Copyright (C) Microsoft Corporation. All rights reserved.

import { HandleTeachingCallout } from './MeControlCallout';

$(function () {
	HandleTeachingCallout();
});