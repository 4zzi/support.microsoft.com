// Copyright (C) Microsoft Corporation. All rights reserved.

import type { ApplicationInsights, Behavior, IContentUpdateOverrideValues } from "@microsoft/1ds-analytics-web-js";
import type { MeControlNamespace, IOnBeforeSwitchToEvent, AccountType } from "@mecontrol/public-api";
import { getSessionStorage, trySetSessionStorage } from '../Common/StorageHelpers';

declare global {
	interface Window {
		analytics?: ApplicationInsights;
		oneDS: {
			Behavior: typeof Behavior;
		};
		MeControl: MeControlNamespace;
		MeControlAccountType: typeof AccountType;
	}
}

enum MeControlAccountSelector {
	EXPANDED = 'meControlAccountSelectorExpanded',
	COLLAPSED = 'meControlAccountSelectorCollapsed',
	SWITCHTYPE = 'meControlSwitchAccountType',
	SWITCHMSA = 'meControlSwitchMSAAccount',
	SWITCHAAD = 'meControlSwitchAADAccount',
}

enum TeachingCalloutLogId {
	REMOVE = 'teachingCalloutRemove',
	SHOWN = 'teachingCalloutShown',
	TIMEOUT = 'teachingCalloutTimeout'
}

let meControl: JQuery<HTMLElement> = $('#meControl');
let teachingCallout: JQuery<HTMLElement> = $('#smcTeachingCalloutPopover');
let teachingCalloutDismiss: JQuery<HTMLElement> = $('#teachingCalloutDismiss');

let flagTeachingCalloutShown = 'teachingCalloutShown';

// Object to hold handler set on timeout
let setTimeoutHandler: number;
let positionCalculatorHandler: number;

export function HandleTeachingCallout() {
	if (teachingCallout && teachingCallout.length > 0) {

		SetTeachingCalloutOffsetPosition(teachingCallout, meControl);

		window.document.addEventListener('displayTeachingCallout', function (event: CustomEvent) {
			// Popup is to be shown only once during the entire session.
			try {
				if (getSessionStorage(flagTeachingCalloutShown) === null && event.detail != undefined) {

					if (event.detail.displayMessageState != undefined) {
						let messageId: string = '#' + event.detail.displayMessageState;
						let displayMessage: JQuery<HTMLElement> = $(messageId);

						if (displayMessage.length != 0) {
							if (event.detail.displayMessageState == 'multipleSignInSuccess' && event.detail.displayName != undefined) {
								let displayCalloutHeadingResource: JQuery<HTMLElement> = $(messageId + ' #calloutHeading');
								let currentText = displayCalloutHeadingResource.text();

								let displayName: string = event.detail.displayName;
								if (displayName.length > 10) {
									displayName = displayName.substring(0, 10).concat('...');
								}

								displayCalloutHeadingResource.text(currentText.concat(' ', displayName));
							}

							displayMessage.removeClass('calloutMessageHidden');

							teachingCallout.removeClass('teachingCalloutHidden');

							teachingCallout.attr('aria-live', 'assertive');

							LogContentUpdate(window.oneDS.Behavior.IMPRESSION, TeachingCalloutLogId.SHOWN);
							trySetSessionStorage(flagTeachingCalloutShown, 'true');

							// Resolves to NaN if 'timeout' is not configured
							var popupTimeoutSeconds = parseInt(teachingCallout.data('timeout'), 10);

							// If timeout is not configured, then popup is made visible for the entirety of the first page duration within session.
							// No timeout event will be logged in this case
							if (popupTimeoutSeconds) {
								setTimeoutHandler = window.setTimeout(function () {
									LogContentUpdate(window.oneDS.Behavior.OTHER, TeachingCalloutLogId.TIMEOUT);
									teachingCallout.slideUp();
									if (positionCalculatorHandler) {
										window.clearInterval(positionCalculatorHandler);
									}
								}, popupTimeoutSeconds * 1000);
							}
						}
					}
				}
			}
			catch (err) {
				if (event.detail == undefined) {
					LogContentUpdate(window.oneDS.Behavior.OTHER, 'calloutDetailNotReceived');
				}
			}
		});

		window.MeControl.API.addEventListener('beforeswitchto', function (e: IOnBeforeSwitchToEvent) {
			if (e.detail.currentAccount.type != e.detail.nextAccount.type) {
				LogContentUpdate(window.oneDS.Behavior.OTHER, MeControlAccountSelector.SWITCHTYPE);
			}
			else {
				if (e.detail.currentAccount.type == window.MeControlAccountType.AAD)
					LogContentUpdate(window.oneDS.Behavior.OTHER, MeControlAccountSelector.SWITCHAAD);
				else if (e.detail.currentAccount.type == window.MeControlAccountType.MSA || e.detail.currentAccount.type == window.MeControlAccountType.MSA_FED)
					LogContentUpdate(window.oneDS.Behavior.OTHER, MeControlAccountSelector.SWITCHMSA);
			}
		});

		window.MeControl.API.addEventListener('controlexpanded', function () {
			LogContentUpdate(window.oneDS.Behavior.IMPRESSION, MeControlAccountSelector.EXPANDED);

			if (!teachingCallout.hasClass('teachingCalloutHidden')) {
				LogContentUpdate(window.oneDS.Behavior.REMOVE, TeachingCalloutLogId.REMOVE);
				teachingCallout.addClass('teachingCalloutHidden');
			}
		});

		window.MeControl.API.addEventListener('controlcollapsed', function () {
			LogContentUpdate(window.oneDS.Behavior.REMOVE, MeControlAccountSelector.COLLAPSED);
		});

		teachingCalloutDismiss.on('click', function () {
			/*e.preventDefault();*/
			if (setTimeoutHandler) {
				window.clearTimeout(setTimeoutHandler);
			}
			teachingCallout.slideUp();

			if (positionCalculatorHandler) {
				window.clearInterval(positionCalculatorHandler);
			}
		});
	}
}

function LogContentUpdate(userBehavior: Behavior, contentIdLog: string) {
	var overrideValues: IContentUpdateOverrideValues = {
		isAuto: false,
		content: {
			contentId: contentIdLog
		},
		behavior: userBehavior
	};

	window.analytics?.captureContentUpdate(overrideValues);
}

function SetTeachingCalloutOffsetPosition(calloutContainer: JQuery<HTMLElement>, dockedElement: JQuery<HTMLElement>) {
	if (!calloutContainer.length || !dockedElement.length) {
		return;
	}

	var initialSignInOffset = calloutContainer.offset().top;
	var intervalRefreshRate = 15;

	positionCalculatorHandler = window.setInterval(function () {
		var dockedElementOffset = dockedElement.offset().top;
		calloutContainer.offset({ top: initialSignInOffset + dockedElementOffset });
	}, intervalRefreshRate);
}
