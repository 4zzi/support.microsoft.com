import { TabControl } from './TabControl';

/**
 * Manages tab controls and synchronizes their state with the URL hash.
 */
export class HashTabManager {
	/** Stores registered TabControl instances. */
	private readonly tabControls: Map<string, TabControl> = new Map();

	/** The event name for hash changes. */
	private static readonly HASH_CHANGE_EVENT = "hashchange";

	/** The separator character for hash key-value pairs. */
	private static readonly HASH_SEPARATOR = "=";

	/**
	 * Initializes a new instance of the HashTabManager class.
	 * Binds event handlers and listens for URL hash changes.
	 */
	constructor() {
		// Bind event handlers
		this.onHashChange = this.onHashChange.bind(this);

		// Listen for URL hash changes (Back/Forward navigation support)
		window.addEventListener(HashTabManager.HASH_CHANGE_EVENT, this.onHashChange);
	}

	/**
	 * Registers a TabControl instance for hash-based updates.
	 * @param tabControl The TabControl instance to register.
	 */
	public registerTabControl(this: HashTabManager, tabControl: TabControl): void {
		const controlId = tabControl.getTabControlId()?.toLowerCase();
		if (controlId) {
			this.tabControls.set(controlId, tabControl);
		}
	}

	/**
	 * Updates the URL hash when a tab is clicked.
	 * @param tabControl The TabControl instance.
	 * @param hashValue The data-tab-hash value of the selected tab.
	 */
	public updateHash(this: HashTabManager, tabControl: TabControl, hashValue: string): void {
		const controlId = tabControl.getTabControlId();
		if (!controlId) { return; }

		const hashValueParts = hashValue.split(HashTabManager.HASH_SEPARATOR);
		if (hashValueParts.length > 1) {
			hashValue = hashValueParts[1];
		}

		// Construct new hash (preserve existing hashes from other TabControls)
		const url = new URL(window.location.href);
		url.hash = this.buildUpdatedHash(url.hash, controlId, hashValue);

		// Update the URL without triggering a reload
		history.pushState(null, "", url.toString());
	}

	/**
	 * Parses the current URL hash and activates the appropriate tabs.
	 */
	public applyHashToTabs(this: HashTabManager): void {
		const urlHash = window.location.hash.substring(1); // Remove '#'
		if (!urlHash) { return; }

		const hashParams = new URLSearchParams(urlHash);

		// Iterate over parameters using forEach (ES5 compatible)
		hashParams.forEach((value, key) => {
			const tabControl = this.tabControls.get(key.toLowerCase());
			if (tabControl) {
				tabControl.activateTabFromHash(`${key}${HashTabManager.HASH_SEPARATOR}${value}`);
			}
		});
	}

	/**
	 * Handles browser back/forward navigation for hash-based tab switching.
	 */
	private onHashChange(this: HashTabManager): void {
		this.applyHashToTabs();
	}

	/**
	 * Constructs an updated hash while preserving existing unrelated tab-control hashes.
	 * @param currentHash The existing hash string.
	 * @param controlId The tab-control ID being updated.
	 * @param hashValue The new hash value for the control.
	 * @returns The updated hash string.
	 */
	private buildUpdatedHash(currentHash: string, controlId: string, hashValue: string): string {
		const params = new URLSearchParams(currentHash.replace(/^#/, ''));

		// Update or add the relevant tab-control hash
		params.set(controlId.toLowerCase(), hashValue.toLowerCase());

		return params.toString();
	}
}
