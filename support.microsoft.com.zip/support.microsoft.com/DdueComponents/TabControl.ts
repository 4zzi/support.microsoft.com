/**
 * @file: Scripts/DdueComponents/TabControl.ts
 * @description: This file contains the TabControl module, which represents an accessible tab control component. 
 * @see https://www.w3.org/WAI/ARIA/apg/patterns/tabs/
 *
 * Guidance: Bundling / Initialization / <script>
 * The TabControl and HashTabManager require the underlying DOM elements to be fully loaded prior to
 * initialization, as such, <script defer> is an appropriate reference mechanism.
 */


import { HashTabManager } from './HashTabManager';

/**
 * Represents an accessible Tab Control component. It integrates with the HashTabManager
 * to synchronize tab states with the URL hash, enabling deep linking and back/forward
 * navigation support.
 */
export class TabControl {
	/** The root element for the TabControl component. */
	private rootElement: HTMLElement;

	/** The element containing all the tabs with role "tablist". */
	private tabsContainer: HTMLElement;

	/** The element containing all the tab panels. */
	private tabPanelsContainer: HTMLElement;

	/** The array of tab elements. */
	private tabs: HTMLElement[] = [];

	/** The array of tab panel elements. */
	private tabPanels: HTMLElement[] = [];

	/** The first tab in the tab list. */
	private firstTab: HTMLElement | null = null;

	/** The last tab in the tab list. */
	private lastTab: HTMLElement | null = null;

	/** The targeted tab position to be selected on initialization, if declared. */
	private targetedTabPosition: number | null = null;

	/** Reference to the HashTabManager (Injected Dependency) */
	private hashManager: HashTabManager | null;

	/** The identifier for the TabControl, used for hash-based navigation. */
	private controlId: string | null;

	/**
	 * Initializes a new instance of the TabControl class.
	 * @param rootElement - The root HTML element for the TabControl.
	 */
	constructor(rootElement: HTMLElement, hashManager: HashTabManager | null = null) {
		this.rootElement = rootElement;
		this.tabsContainer = this.rootElement.querySelector<HTMLElement>("[role='tablist']")!;
		this.tabPanelsContainer = this.rootElement.querySelector<HTMLElement>(".tabControl_tabPanelContainer")!;
		this.hashManager = hashManager;

		if (!this.tabsContainer || !this.tabPanelsContainer) {
			console.error(`TabControl initialization failed: Required elements not found in root element ID '${this.rootElement.id}'.`);
			return;
		}

		// Retrieve the control ID for hash tracking (if applicable)
		this.controlId = this.rootElement.getAttribute("data-tab-control");

		// Register this TabControl with the HashTabManager if it has a control ID
		if (this.hashManager && this.controlId) {
			this.hashManager.registerTabControl(this);
		}
		// Bind event handlers to ensure correct 'this' reference
		this.onKeydown = this.onKeydown.bind(this);
		this.onClick = this.onClick.bind(this);

		// Initialize the tab control elements
		this.initialize();
	}

	/** Returns the control ID of the TabControl */
	public getTabControlId(): string | null {
		return this.controlId;
	}

	/** Activates a tab based on a hash value */
	public activateTabFromHash(hashValue: string) {
		this.setSelectedTabByHash(hashValue);
	}

	/**
	 * Initializes the TabControl by identifying tabs, panels, and setting up event listeners.
	 */
	private initialize(this: TabControl): void {
		const tabElements = Array.from(this.tabsContainer.querySelectorAll<HTMLElement>("[role='tab']"));

		// Warn the developer if no tabs are found
		if (tabElements.length === 0) {
			console.error("No tabs found in the TabControl.");
			return;
		}

		// Warn the developer if the number of tabs does not match the number of tab panels
		const tabPanelElements = Array.from(this.tabPanelsContainer.querySelectorAll<HTMLElement>("[role='tabpanel']"));
		if (tabElements.length !== tabPanelElements.length) {
			console.error("The number of tabs does not match the number of tab panels.");
			return;
		}

		// Assign the tabs array
		this.tabs = tabElements;

		// Get the targeted tab position if declared
		this.targetedTabPosition = this.getTargetedTabIndex();

		/**
		 * Iterate over each tab, capture a reference to the associated tabPanel, and add it to the member variable containing
		 * the tabPanels. We only initialize tabPanels that have a direct association with a tab
		 */
		this.tabs.forEach((currentTab, index) => {
			const tabPanelId = currentTab.getAttribute("aria-controls");

			// Warn the developer if the currentTab does not have an aria-controls attribute. This will prevent interaction
			if (!tabPanelId) {
				console.error(`Tab at index ${index} is missing 'aria-controls' attribute.`);
				return;
			}

			const tabPanel = this.tabPanelsContainer.querySelector<HTMLElement>(`#${tabPanelId}`);
			// Warn the developer if the associated tabPanel cannot be found. 
			if (!tabPanel) {
				console.error(`TabPanel with ID '${tabPanelId}' not found.`);
				return;
			}

			// Check for required attributes and log warnings if they are missing or invalid
			if (tabPanel.getAttribute("aria-labelledby") !== currentTab.id) {
				console.error(`TabPanel with ID '${tabPanelId}' does not have a valid 'aria-labelledby' attribute.`);
			}

			if (tabPanel.getAttribute("role") !== "tabpanel") {
				console.error(`TabPanel with ID '${tabPanelId}' has an invalid 'role' attribute.`);
			}

			this.tabPanels.push(tabPanel);

			// Register event listeners for keyboard and click interactions
			currentTab.addEventListener("keydown", this.onKeydown);
			currentTab.addEventListener("click", this.onClick);

			// Track first and last tabs
			if (this.firstTab === null) {
				this.firstTab = currentTab;
			}
			this.lastTab = currentTab;
		});

		/**
		 * Now that all tabs and tab panels have been initialized, we must exercise the 'setSelectedTab' function
		 * to ensure aria-selected attributes and the focusable content from hidden tabs has focus removed.
		 * 
		 * On intial execution, it does set the hidden values to what they were server side, but also handles the
		 * toggling of tabindex for all focusable elements.  This is a neglible performance impact for first run.
		 *
		 * We prioritize the hash-based tab activation to ensure embedded product and FWLinks are honored over
		 * client-detected targeting (OS, Windows Version, or Office Version)
		 */

		// Convert the current URL hash to lowercase for comparison
		const hash = window.location.hash.toLowerCase();

		// Check if hashManager and controlId are defined and if the URL hash includes the controlId
		if (this.hashManager && this.controlId && hash.includes(this.controlId.toLowerCase())) {
			// Apply the hash to the tabs using the hashManager
			this.hashManager.applyHashToTabs();
		} else {
			// Determine the tab to select: targetedTabPosition if valid, otherwise the firstTab
			const tabToSelect = this.targetedTabPosition !== null && this.targetedTabPosition >= 0
				? this.tabs[this.targetedTabPosition]
				: this.firstTab;

			// If a valid tab is found, set it as the selected tab
			if (tabToSelect) {
				this.setSelectedTab(tabToSelect, false, false);
			} else {
				// Log a warning if no valid tabs are found
				console.warn("No valid tabs were found.");
			}
		}
	}

	/** Selects a tab based on a hash match */
	private setSelectedTabByHash(this: TabControl, hashValue: string) {
		const targetTab = this.tabs.find(tab => tab.getAttribute("data-tab-hash")?.toLowerCase() === hashValue.toLowerCase());

		if (targetTab) {
			this.setSelectedTab(targetTab);
		} else {
			console.warn(`[TabControl] No tab found matching hash: ${hashValue}`);
		}
	}

	/**
	 * Gets the targeted tab position from the root element attribute.
	 * @this {TabControl} The TabControl instance.
	 * @returns {number | null} The targeted tab position if valid, otherwise null.
	 */
	private getTargetedTabIndex(this: TabControl): number | null {
		// Get the targeted tab position attribute
		const attributeValue = this.rootElement.getAttribute("data-targeted-tab-position");
		if (!attributeValue) return null;

		const index = Number(attributeValue) - 1;
		if (isNaN(index) || index < 0 || index >= this.tabs.length) {
			console.error(`Invalid 'data-targeted-tab-position': '${attributeValue}'. Must be between 1 and ${this.tabs.length}.`);
			return null;
		}
		return index;

	}

	/**
	 * Sets the selected tab and updates the corresponding panel.
	 * @this {TabControl} The TabControl instance.
	 * @param {HTMLElement} currentTab - The tab element to be selected.
	 * @param {boolean} [setFocus=true] - Whether to set focus on the newly selected tab.
	 * @param {boolean} [updateUrlHash=true] - Whether to update the address bar url hash. 
	 */
	private setSelectedTab(this: TabControl, currentTab: HTMLElement, setFocus: boolean = true, updateUrlHash: boolean = true): void {
		this.tabs.forEach((tab, index) => {
			const isSelected = currentTab === tab;
			tab.setAttribute("aria-selected", String(isSelected));
			this.toggleTabPanelVisibility(this.tabPanels[index], isSelected);

			if (isSelected) {
				tab.removeAttribute("tabindex"); // Remove the tabindex so it defaults to focusable and is Tab-key accessible

				if (setFocus) {
					tab.focus();
				}
				if (updateUrlHash) {
					this.updateUrlHash(tab);
				}
			} else {
				tab.setAttribute("tabindex", "-1") // Set the tabindex to -1 to remove it from Tab-key navigation and is only accessible from arrow keys
			}
		});
	}

	/**
	 * Moves selection to the previous tab in the list.
	 * @this {TabControl} The TabControl instance.
	 * @param {HTMLElement} currentTab - The currently selected tab.
	 */
	private setSelectedToPreviousTab(this: TabControl, currentTab: HTMLElement): void {
		if (!this.tabs.length) {
			return;
		}

		const index = this.tabs.indexOf(currentTab);

		// Set the previous tab as selected, or wrap around to the last tab
		this.setSelectedTab(this.tabs[(index - 1 + this.tabs.length) % this.tabs.length]);
	}

	/**
	 * Moves selection to the next tab in the list.
	 * @this {TabControl} The TabControl instance.
	 * @param {HTMLElement} currentTab - The currently selected tab.
	 */
	private setSelectedToNextTab(this: TabControl, currentTab: HTMLElement): void {
		if (!this.tabs.length) {
			return;
		}

		const index = this.tabs.indexOf(currentTab);

		// Set the next tab as selected, or wrap around to the first tab
		this.setSelectedTab(this.tabs[(index + 1) % this.tabs.length]);
	}

	/**
	 * Toggles the visibility of a tab panel to ensure accessibility compliance.
	 * @param {HTMLElement} tabPanel - The tab panel element.
	 * @param {boolean} isVisible - Whether the tab panel should be visible.
	 */
	private toggleTabPanelVisibility(tabPanel: HTMLElement, isVisible: boolean): void {
		if (!tabPanel) {
			return;
		}

		// Set the tab panel to hidden if it should not be visible
		tabPanel.toggleAttribute("hidden", !isVisible);

		// Update the tabindex of focusable elements within the tab panel
		tabPanel.querySelectorAll<HTMLElement>("a, button, input, select, textarea").forEach(element => {
			element.setAttribute("tabindex", isVisible ? "0" : "-1");
		});
	}

	/**
	 * Handles keyboard navigation between tabs.
	 * @this {TabControl} The TabControl instance.
	 * @param event - The keyboard event object.
	 */
	private onKeydown(this: TabControl, event: KeyboardEvent): void {
		const targetElement = event.currentTarget as HTMLElement;
		if (!targetElement) {
			return;
		}

		let handled = false;

		switch (event.key) {
			case "ArrowLeft":
			case "Left":
				this.setSelectedToPreviousTab(targetElement);
				handled = true;
				break;
			case "ArrowRight":
			case "Right":
				this.setSelectedToNextTab(targetElement);
				handled = true;
				break;
			case "Home":
				if (this.firstTab) {
					this.setSelectedTab(this.firstTab);
				}
				handled = true;
				break;
			case "End":
				if (this.lastTab) {
					this.setSelectedTab(this.lastTab);
				}
				handled = true;
				break;
		}

		if (handled) {
			event.preventDefault();
			event.stopPropagation();
		}
	}

	private updateUrlHash(this: TabControl, targetElement: HTMLElement): void {
		if (this.hashManager && this.controlId) {
			const hashValue = targetElement.getAttribute("data-tab-hash");
			if (hashValue) {
				this.hashManager.updateHash(this, hashValue);
			}
		}
	}

	/**
	 * Handles tab selection via click.
	 * @this {TabControl} The TabControl instance.
	 * @param {MouseEvent} event - The (Mouse) click event object.
	 */
	private onClick(this: TabControl, event: MouseEvent): void {
		const targetElement = event.currentTarget as HTMLElement;
		if (!targetElement) return;

		this.setSelectedTab(targetElement);
	}
}

/**
 * Initializes all TabControl components found in the document.
 */
export function initializeTabControls(): void {
	// Create the HashTabManager instance for the page view
	const hashManager = new HashTabManager();

	// Query for all instances of the TabControl and initialize them
	document.querySelectorAll<HTMLElement>("[data-tab-control]").forEach(rootNode => {
		new TabControl(rootNode, hashManager);
	});

	// After all instances have been initialized, apply the hash to the tab controls.
	hashManager.applyHashToTabs();
}

/** Automatically initialize tab controls on DOM ready */
document.addEventListener("DOMContentLoaded", initializeTabControls);
