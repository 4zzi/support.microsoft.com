// Copyright (C) Microsoft Corporation. All rights reserved.
import type { UniversalMediaPlayer } from "universal-media-player";

export const containerSelector = 'div.videoContainer';
export const videoAreaSelector = 'div.cardControlCarouselVideoArea';

export function InitializeCarouselModalEvents() {
	const breakpoints: number[] = [900, 768, 480];

	breakpoints.forEach((breakpoint: number) => {
		window.matchMedia(`(max-width: ${breakpoint}px)`).addEventListener('change', () => {
			resetCarouselVideoModal();
		});
	});

	$(window).on('resize', function () {
		resizeModal($('.modalContainer').closest('.supCardControlCard'));
	});

	// Use event delegation to listen click event since slick.js will
	// re-initialize when number of card number is not default value and
	// event delegation is able to attach dynamic content for the event
	// listener.
	$(document).on('click', '.modalCloseButton, .modalPageBackground', function () {
		resetCarouselVideoModal();
	});
}

export function setCarouselVideoModal(carouselCard: JQuery<HTMLElement>) {

	if (carouselCard.length <= 0) {
		return;
	}

	const $carousel = carouselCard.closest('div.supCardControlCarousel');
	const $modalContainer = carouselCard.find(containerSelector);
	const $modalContent = $modalContainer.find('div.videoContent');
	const $closeButton = $modalContainer.find('span.modalCloseButton');

	$modalContainer.addClass('modalContainer');
	$modalContainer.find('.modalCloseButton').css('display', 'block');
	$modalContainer.find('.supCardControlImage').css('display', 'none');
	$modalContainer.siblings('.modalPageBackground').css('display', 'block');
	$modalContent.addClass('modalContent');
	$closeButton.css('display', 'block');
	$closeButton.attr("tabindex", "0");

	$('[class^="slick-"]').each(function () {
		$(this).addClass('resetTransform');
	});

	$carousel.find('.supCardControlCarouselPrevButton, .supCardControlCarouselNextButton').not('.slick-hidden').hide();
	$('body').addClass('disableScroll');

	$modalContainer[0].addEventListener('keydown', onModalContainerKeyDown, true);
	resizeModal(carouselCard);
}

function onModalContainerKeyDown(event: KeyboardEvent) {
	const isEscape: boolean = event.key === 'Escape';
	const isEnterOnModalCloseButton: boolean = event.key === 'Enter' && $(event.target).hasClass('modalCloseButton');
	const isTab: boolean = event.key === 'Tab';
	const isShift: boolean = event.shiftKey;
	const container = event.currentTarget as HTMLElement;
	const player = container.querySelector<UniversalMediaPlayer>('universal-media-player');

	if ((isEscape && !player.currentState.openControls) || isEnterOnModalCloseButton) {
		resetCarouselVideoModal();
	} else if (isTab && !isShift && $(event.target).hasClass('modalCloseButton')) {
		$(event.target).closest('.slick-active').focus();
		event.preventDefault();
	} else if (isTab && isShift && $(event.target).hasClass('slick-active')) {
		$(event.target).find('.modalCloseButton').focus();
		event.preventDefault();
	}
}

function resetCarouselVideoModal() {
	const $modalContainer = $('.modalContainer');
	if ($modalContainer.length == 0) {
		return;
	}
	const $carouselCard = $modalContainer.closest('.supCardControlCard');
	const $carousel = $carouselCard.closest('div.supCardControlCarousel');
	const $closeButton = $modalContainer.find('span.modalCloseButton');
	const $modalContent = $modalContainer.find('div.videoContent');
	const $cardControlCarouselVideoArea = $modalContent.find(videoAreaSelector);

	$modalContainer.removeClass('modalContainer');
	$modalContainer.find('div.modalCloseButton').css('display', 'none');
	$modalContainer.find('.supCardControlImage').css('display', 'block');
	$modalContainer.siblings('.modalPageBackground').css('display', 'none');
	$modalContent.removeClass('modalContent');
	$closeButton.removeAttr("tabindex");
	$closeButton.css('display', 'none');

	$cardControlCarouselVideoArea.attr('hidden', 'true');

	$('[class^="slick-"]').each(function () {
		$(this).removeClass('resetTransform');
	});

	$carousel.find('.supCardControlCarouselPrevButton, .supCardControlCarouselNextButton').not('.slick-hidden').show();

	$modalContainer.css({
		'width': '',
		'height': '',
		'top': '',
		'left': ''
	});

	$modalContent.css({
		'width': '',
		'height': ''
	});

	$('body').removeClass('disableScroll');

	$modalContainer[0].removeEventListener('keydown', onModalContainerKeyDown, true);

	// Pause video play
	window.occe.suspendStateOfContents($modalContent);
}

function resizeModal(carouselCard: JQuery<HTMLElement>) {
	if (carouselCard.length <= 0) {
		return;
	}

	const $window = $(window);
	const $modalContainer = carouselCard.find(containerSelector);
	const $modalContent = $modalContainer.find('div.videoContent');
	const ratio = 16 / 9;

	if ($window.height() < $window.width() / ratio) {
		$modalContainer.height("95vh");
		$modalContainer.width(($modalContainer.height() - 80) * ratio + 80);
	} else {
		$modalContainer.width("95vw");
		$modalContainer.height(($modalContainer.width() - 80) / ratio + 80);
	}

	const top = $window.height() / 2 - $modalContainer.height() / 2;
	const left = $window.width() / 2 - $modalContainer.width() / 2;

	$modalContainer.css('top', top + 'px');
	$modalContainer.css('left', left + 'px');

	$modalContent.width($modalContainer.width() - 80);
	$modalContent.height($modalContainer.height() - 80);
}
