// Copyright (C) Microsoft Corporation. All rights reserved.

import { setUpShimmerDelay } from "./shimmerExperiment";

window.addEventListener("load", setUpShimmerDelay);
