export function setUpShimmerDelay() {
	let ocpSections = getHtmlElementsByClass(".ocpSectionLayout .ocpSection");
	let shimmerElements = getHtmlElementsByClass(".ocpSectionLayout .shimmer-effect");

	//Length should be the same for both arrays. However, failsafe to just remove the shimmer if they're unequal.
	if (ocpSections.length === shimmerElements.length) {
		for (let i = 0; i < shimmerElements.length; i++) {
			let shimmerDelay = getShimmerDelay(shimmerElements[i]);
			setTimeout(removeShimmer, shimmerDelay, shimmerElements[i], ocpSections[i]);
		}
	} else {
		shimmerElements.forEach((element) => {
			element.remove();
		});

		ocpSections.forEach((section) => {
			section.style.removeProperty("display");
		});
	}
}

function getHtmlElementsByClass(className: string): NodeListOf<HTMLElement> {
	return document.querySelectorAll<HTMLElement>(className);
}

function getShimmerDelay(element: HTMLElement): number {
	return Number(element.getAttribute("shimmer-delay"));
}

function removeShimmer(shimmerElement: HTMLElement, sectionElement: HTMLElement) {
	shimmerElement.remove();
	sectionElement.style.removeProperty("display");
}
