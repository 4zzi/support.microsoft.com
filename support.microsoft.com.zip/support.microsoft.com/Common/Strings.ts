// Copyright (C) Microsoft Corporation. All rights reserved.

// Silent Sign In
export const eventNameSilentSignInComplete = "silentSignInComplete";

// Popup Sign In
export const eventNamePopupSignInComplete = "popupSignInComplete";

// Value Guidance strings
export const eventNameVgSignInSuccess = "vg.signin.success";
export const eventNameVgSignInFailed = "vg.signin.failed";

export const vgComponentNames = {
	vgHero: 'vg-hero',
	vgExplore: 'vg-explore'
}

export const HvcComponentType = {
	[vgComponentNames.vgHero]: 'ValueGuidanceV2HvcHero',
	[vgComponentNames.vgExplore]: 'ValueGuidanceV2HvcExplore'
}

export const TenantAdminPoliciesElementId = "TAP__SETTINGS";
