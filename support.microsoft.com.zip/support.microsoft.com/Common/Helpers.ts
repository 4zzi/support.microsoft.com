// Copyright (C) Microsoft Corporation. All rights reserved.
import { MeControlAccount, DataBoundary } from '../Common/AuthenticationTypes';

/*
 * @param {string} authType - authentication type from user auth object
 * @returns {boolean} - true if user is authenticated, false otherwise
 */
export const isUserAuthenticated = (authType: string): boolean => (authType && (authType != '') ? authType.toLowerCase() != 'none' : false);

/*
 * @returns {MeControlAccount} - returns current user account information if available
 */
export const getCurrUser = (): MeControlAccount  => (window?.msCommonShell?.meControlOptions()?.currentAccount);

/*
 * @param {string} authType - authentication type from user auth object
 * @returns {boolean} - true if user is AAD user, false otherwise
 */
export const isAadUser = (authType): boolean => !!authType && (authType.toLowerCase() === "aad");

/*
 * @param {window} window - window to close
 */
export const closeWindow = (window: Window | undefined | null): void => window?.close();

/*
 * Returns valid data source
 * @param {string} dataBoundary - data boundary from user auth object
 */
export const parseDataBoundary = (dataBoundary: string): DataBoundary => (dataBoundary === DataBoundary.EU ? DataBoundary.EU : DataBoundary.None);

/*
 * @param {string} url - URL to open in pop up window
 * @param {string} width - width of the window
 * @param {string} height - height of the window
 * @returns {Window} - returns the window created
 */
export const createPopUpWindow = (url: string, width: number, height: number) : Window | null => {
	if (window) {
		const wLeft = window.screenLeft ? window.screenLeft : window.screenX;
		const wTop = window.screenTop ? window.screenTop : window.screenY;

		const left = wLeft + (window.innerWidth / 2) - (width / 2);
		const top = wTop + (window.innerHeight / 2) - (height / 2);
		return window.open(url, '_blank', `popup=yes, width=${width}, height=${height}, top=${top}, left=${left}`);
	}
	return null;
}

/*
 * @param {MeControlAccount} userAccount - sets MeControlAccount in msCommonShell
 * @param {window} win - window to set MeControlAccount in
 */
export const SetMeControlAccount = (userAccount: MeControlAccount, window: any): void => {
	// ToDo: pattri, #7729785 set type for window
	window?.MeControl?.API?.setActiveAccount(userAccount);
}
