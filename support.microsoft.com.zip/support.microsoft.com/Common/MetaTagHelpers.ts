// Copyright (C) Microsoft Corporation. All rights reserved.

import type { ApplicationInsights } from '@microsoft/1ds-analytics-web-js';

declare global {
	interface Window {
		analytics?: ApplicationInsights
	}
}

export const refreshTelemetryMetadata = () => {
	const analytics = window.analytics;

	if (analytics) {
		try {
			analytics.getWebAnalyticsExtension().refreshMetadata();
		} catch (e) {
			analytics.trackException({
				exception: {
					name: 'CustomError',
					message: `Failed to refresh 1DS metadata: ${e}`,
				}
			})
		}
	}
};

const getMetaTag = (name: string): HTMLMetaElement | undefined => document.getElementsByTagName('meta').namedItem(name);

export const getMetaTagValue = (name: string): string | undefined => getMetaTag(name)?.content;

export const setMetaTag = (name: string, value: string) => {
	let tag = getMetaTag(name);
	if (tag) {
		tag.content = value;
	}
	else {
		let element = document.createElement('meta');
		element.name = name;
		element.content = value;

		document.head.appendChild(element);
	}

	refreshTelemetryMetadata();
};
