// Copyright (C) Microsoft Corporation. All rights reserved.

function isUpperCaseMatch(left: string, right: string) {
	return left.toUpperCase() === right.toUpperCase();
}

export default class HashManager {
	private readonly callbacks = new Map<string, Function>();
	private hashValues: Array<string> = [];

	setCallback(this: HashManager, key: string, callback: Function) {
		this.callbacks.set(key.toUpperCase(), callback);
	}

	append(this: HashManager, value: string) {
		// exact match with existing values, return
		if (this.hashValues.findIndex(v => isUpperCaseMatch(value, v)) !== -1) {
			return;
		}

		const tuple = value.split('=');

		// not a tuple, add
		if (tuple.length === 1) {
			this.hashValues.push(value);
		}
		else {
			// tuple, find existing value with matching first tuple element
			const index = this.hashValues.findIndex(v => {
				const t = v.split('=');
				if (t.length > 1 && isUpperCaseMatch(t[0], tuple[0])) {
					return true;
				}
			});

			// update or add
			if (index !== -1) {
				this.hashValues[index] = value;
			}
			else {
				this.hashValues.push(value);
			}
		}

		this.callbacks.get(value.toUpperCase())?.();
	}

	replaceAll(this: HashManager, location: Location) {
		const hash = location.hash.substring(1);

		if (hash.length === 0) {
			return;
		}

		const replacementValues = hash.split('&');

		// append on existing (will trigger callbacks for updated items)
		for (const value of replacementValues) {
			this.append(value);
		}

		// set existing to new set (removes old items that don't have replacements and preserves new ordering)
		this.hashValues = replacementValues;
	}

	toHashString(this: HashManager) {
		return this.hashValues.join('&');
	}
}
