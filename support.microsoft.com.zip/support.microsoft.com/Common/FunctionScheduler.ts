// Copyright (C) Microsoft Corporation. All rights reserved.

export const scheduleImmediateCallback = (f: Function, t, ...args): number =>
	window.setTimeout(() => f.apply(t, args), 0);
