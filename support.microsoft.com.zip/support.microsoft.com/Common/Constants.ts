// Copyright (C) Microsoft Corporation. All rights reserved.

export const wedcsConstants = {
	componentGroup: {
		outcomeDrivenHelp: 'ODH',
		cssControl: 'CSSControl',
	},
	interactionType: {
		formSubmit: '2',
		samePage: '11',
		completedFinalStepInSeries: '22',
	},
	coreEventType: {
		pageView: '0',
		anchorLinkClick: '1',
		imageLinkClick: '2',
		imageAreaClick: '3',
		imputClick: '4',
		customEvent: '5',
		pageUnload: '11',
	},
	endActionAction: {
		goto: 'Goto',
		send: 'Send',
	},
	endActionOffer: {
		phone: 'PHN',
		contact: 'Contact',
	}
};

export const eventConstants = {
	CLICK_EVENT_TYPE: 'click',
	COPY_EVENT_TYPE: 'copy',
	TAB_KEYCODE: 9,
	ENTER_KEYCODE: 13,
	ESC_KEYCODE: 27,
	DOWN_KEYCODE: 40,
	UP_KEYCODE: 38,
};

export const styleTransitionMs = 10;

export const hiddenClass = 'ocHidden';
