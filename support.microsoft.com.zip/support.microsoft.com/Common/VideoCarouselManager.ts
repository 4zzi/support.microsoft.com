// Copyright (C) Microsoft Corporation. All rights reserved.

import type VideoPlayerManager from './VideoPlayerManager';
import type { UniversalMediaPlayer } from 'universal-media-player';
import { VideoContainerSelector, VideoPlayerElementName } from './VideoPlayerManager';

export default class VideoCarouselManager {
	private readonly videoPlayerManager: VideoPlayerManager;

	private static previousButtonClass = 'ocPrev';
	private static nextButtonClass = 'ocNext';

	private static leftIconClass = 'ms-Icon--chevronThinLeft';
	private static rightIconClass = 'ms-Icon--chevronThinRight';

	private static inactiveButtonClass = 'inactive';

	private static selectedClass = 'selected';

	constructor(videoPlayerManager: VideoPlayerManager) {
		this.videoPlayerManager = videoPlayerManager;
	}

	setupCarousel(this: VideoCarouselManager, element: HTMLUListElement) {
		const carouselElement = $(element);

		// note: incorrect typing on prev() method
		const videoContainer = carouselElement.prev(VideoContainerSelector).detach();

		carouselElement.wrap('<div class="trainingCont"></div>');
		carouselElement.before(videoContainer);

		// assumes document direction is equal to content direction
		// existing BUG: does not work with RTL markets with fallback LTR content
		const rtl = element.ownerDocument.dir === 'rtl';

		const nextButton = $('<div></div>', element.ownerDocument).addClass([
			VideoCarouselManager.nextButtonClass,
			VideoCarouselManager.rightIconClass
		]);

		const previousButton = $('<div></div>', element.ownerDocument).addClass([
			VideoCarouselManager.previousButtonClass,
			VideoCarouselManager.inactiveButtonClass,
			VideoCarouselManager.leftIconClass
		]);

		if (rtl) {
			nextButton.insertBefore(carouselElement);
			previousButton.insertAfter(carouselElement);
		}
		else {
			nextButton.insertAfter(carouselElement);
			previousButton.insertBefore(carouselElement);
		}

		// existing BUG: multiple carousels not supported due to element ID
		carouselElement.wrap('<div id="ocpCarousel"></div>');

		const carouselItems = carouselElement.children('li');

		carouselItems.first().addClass(VideoCarouselManager.selectedClass);

		carouselItems.each((i, element) => {
			const item = $(element);

			item.find('ul').find('li:first-child').after(`<li class="ocpCarouselN">${i + 1}</li>`);
			item.click(e => {
				e.preventDefault();

				let target = $(e.delegateTarget);

				target.siblings('li').removeClass(VideoCarouselManager.selectedClass);
				target.addClass(VideoCarouselManager.selectedClass);

				this.videoPlayerManager.setupVideo(videoContainer[0].querySelector<UniversalMediaPlayer>(VideoPlayerElementName));
			});
		});

		// note: logic below is a straight copy from OdcSup; it's convoluted

		const w = carouselItems.width() + 11, ulLength = carouselItems.length;
		let pClicked = false, nClicked = false;

		if (ulLength <= 4) {
			nextButton.addClass(VideoCarouselManager.inactiveButtonClass);
			nClicked = true;
		}

		const slideDirection = rtl ? 'left' : 'right';

		nextButton.click(e => {
			let cp = carouselElement.css(slideDirection).replace(/[px]/g, '');

			if (!nClicked && (cp === 'auto' || parseInt(cp, 10) < ((ulLength - 4) * w))) {
				nClicked = true;

				const animationProperties = rtl
					? { left: `+=${w}px` }
					: { right: `+=${w}px` };

				previousButton.removeClass(VideoCarouselManager.inactiveButtonClass);

				carouselElement.animate(animationProperties, () => {
					nClicked = false;
				});

				cp = carouselElement.css(slideDirection).replace(/[px]/g, '');

				if (parseInt(cp, 10) >= ((ulLength - 5) * w)) {
					$(e.delegateTarget).addClass(VideoCarouselManager.inactiveButtonClass);
				}
			}
			else {
				$(e.delegateTarget).addClass(VideoCarouselManager.inactiveButtonClass);
			}
		});

		previousButton.click(e => {
			const cp = parseInt(carouselElement.css(slideDirection).replace(/[px]/g, ''), 10);

			if (!pClicked && cp > 0) {
				pClicked = true;

				const animationProperties = rtl
					? { left: `-=${w}px` }
					: { right: `-=${w}px` }

				nextButton.removeClass(VideoCarouselManager.inactiveButtonClass);

				carouselElement.animate(animationProperties, () => {
					pClicked = false;
				});

				$(e.delegateTarget).removeClass(VideoCarouselManager.inactiveButtonClass);
			}

			if (cp - w === 0) {
				$(e.delegateTarget).addClass(VideoCarouselManager.inactiveButtonClass);
			}
		});
	}
}
