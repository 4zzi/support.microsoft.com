// Copyright (C) Microsoft Corporation. All rights reserved.

import { SilentSignInProperties } from "../AuthenticationTypes";
import { getMetaTagValue } from "../MetaTagHelpers";
import { eventNameSilentSignInComplete } from "../Strings";

//todo: move some of the auth helpers from Helpers.ts to here

/**
 * Checks if the user is authenticated by looking at the 
 * current me control account, as well as the meta tag values for auth type and tenant id
 * @returns true if the user is authenticated, false otherwise
 */
export function isUserAuthenticated(): boolean {
    return (!!getMetaTagValue("awa-authtype") || !!getMetaTagValue("awa-tenantid") || !!window.msCommonShell?.meControlOptions()?.currentAccount);
}

/**
 * Checks to see if the silent auth event will fire by looking
 * at the silentSigninProgress global variable first and then
 * checking to see if the silent auth iframe is on the page
 * @returns true if the silent auth event will fire, false otherwise
 */
export function willSilentAuthEventFire(): boolean {
    if (typeof window.silentSigninProgress !== 'undefined') {
        return window.silentSigninProgress;
    }

    return !!document.getElementById("iframeOP");
}

/**
 * Adds an event listener for the silent auth event and takes an option timeout parameter
 * for how long to wait for the event to fire. If the event does not fire within the timeout period 
 * the listener will be removed and the callback will be called when the timeout expires.
 * @param listener the callback to be called when the silent auth event fires or the timeout expires
 * @param timeout the amount of time (in milliseconds) to wait for the silent auth event to fire
 */
export function addSilentAuthEventListener(listener: (event: CustomEvent<SilentSignInProperties | Error>) => any, timeout?: number, options?: boolean | AddEventListenerOptions): void {
    
    if(!timeout){
        window.addEventListener(eventNameSilentSignInComplete, listener, options);
        return;
    }
    
    //handles silent auth event by removing the timeout and calling the listener callback
    function silentAuthEventCallbackWrapper(event: CustomEvent<SilentSignInProperties>){
        clearTimeout(timeoutHandler);
        listener(event);
    }

    //handles the timeout by removing the silent auth listener and calling the listener callback with error
    function timeoutCallback(){
        window.removeEventListener(eventNameSilentSignInComplete, silentAuthEventCallbackWrapper);
        listener(new CustomEvent(eventNameSilentSignInComplete, { detail: new Error(`Silent auth did not complete before allowed timeout of ${timeout}`) }));
    }

    let timeoutHandler = setTimeout(timeoutCallback, timeout);
    window.addEventListener(eventNameSilentSignInComplete, silentAuthEventCallbackWrapper, options);
}