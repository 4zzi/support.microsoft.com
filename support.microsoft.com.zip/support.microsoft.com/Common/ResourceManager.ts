// Copyright (C) Microsoft Corporation. All rights reserved.

import { getMetaTagValue } from './MetaTagHelpers';

function updateRecord<TKey extends string | number | symbol, TValue>(
	existingRecords: Record<TKey, TValue>,
	newRecords: Record<TKey, TValue>): void {
	for (let key in newRecords) {
		existingRecords[key] = newRecords[key];
	}
}

export default class ResourceManager {
	private readonly localizedStrings: Record<string, string> = {};
	private readonly settings: Record<string, string> = {};

	addLocalizedStrings(this: ResourceManager, localizedStrings: Record<string, string>) {
		updateRecord(this.localizedStrings, localizedStrings);
	}

	getLocalizedString(this: ResourceManager, key: string): string | undefined {
		return this.localizedStrings[key];
	}

	addSettings(this: ResourceManager, settings: Record<string, string>) {
		updateRecord(this.settings, settings);
	}

	getSetting(this: ResourceManager, key: string): string | undefined {
		return this.settings[key];
	}

	getMetadata(key: string): string | undefined {
		return getMetaTagValue(key);
	}
}
