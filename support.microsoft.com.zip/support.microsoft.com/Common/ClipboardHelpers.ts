// Copyright (C) Microsoft Corporation. All rights reserved.

export const copyElementContents = (element: HTMLElement) => {
	const range = document.createRange();
	range.selectNode(element);

	const selection = window.getSelection();
	selection.removeAllRanges();
	selection.addRange(range);

	document.execCommand('copy');
	selection.removeAllRanges();
}
