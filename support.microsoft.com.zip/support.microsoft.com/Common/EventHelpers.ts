// Copyright (C) Microsoft Corporation. All rights reserved.

import { eventConstants } from './Constants';

type JQueryEventTest = (e: JQuery.Event) => boolean;

export const eventIsClick: JQueryEventTest = e => e.type === eventConstants.CLICK_EVENT_TYPE;
export const eventIsEnterKeypress: JQueryEventTest = e => e.which === eventConstants.ENTER_KEYCODE;
export const eventIsEscKeypress: JQueryEventTest = e => e.which === eventConstants.ESC_KEYCODE;
export const eventIsTabKeypress: JQueryEventTest = e => e.which === eventConstants.TAB_KEYCODE;
export const eventIsDownKeypress: JQueryEventTest = e => e.which === eventConstants.DOWN_KEYCODE;
export const eventIsUpKeypress: JQueryEventTest = e => e.which === eventConstants.UP_KEYCODE;
