// Copyright (C) Microsoft Corporation. All rights reserved.
//Use this method to log copy events.
//Example of copy event, (on Windows)select text and press Control + C.
//We do not log the event if copied text is empty.

export const logCopyEvent = () => {
	const selection = document.getSelection();
	const text = selection.toString().trim();
	const analytics = window.analytics;
	if (analytics && text) {
		analytics.capturePageAction(null, {
			actionType: 'O',
			behavior: window.oneDS.Behavior.COPY,
			contentTags: {
				'contentId': 'copy_text_action',
			}
		});
	}
}
