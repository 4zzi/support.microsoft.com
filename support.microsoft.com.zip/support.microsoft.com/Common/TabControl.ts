// Copyright (C) Microsoft Corporation. All rights reserved.

import { eventConstants, hiddenClass } from './Constants';
import { cardContainerSelector } from './CardCarouselHelpers';
import type { ApplicationInsights, Behavior } from '@microsoft/1ds-analytics-web-js';

declare global {
	interface Window {
		analytics?: ApplicationInsights,
		oneDS: {
			Behavior: typeof Behavior,
		},
	}
}

type HashManager = {
	addHashElementCallback: (value: string, callback: Function) => void,
	appendHashElement: (value: string) => void,
}

export type TabConfigLog = {
	name: string,
	activetab: string,
	defaulttab: string,
	istargeted: string,
}

export const headerContainerActiveTabAttribute = 'ms.activetab';
export const activeTabClass = 'supTabControlHeaderActive';
export const tabContentPositionAttribute = 'referenced-content-position';

function logAction(tabConfigPageTags: Record<string, TabConfigLog>, tab: HTMLAnchorElement, eventType: string) {
	const analytics = window.analytics;

	if (analytics) {
		analytics.capturePageAction(null, {
			behavior: window.oneDS.Behavior.TAB,
			pageTags: {
				tabconfig: tabConfigPageTags,
			},
			actionType: eventType === eventConstants.CLICK_EVENT_TYPE ? 'CL' : undefined,
			contentTags: {
				areaName: 'tabs',
				contentName: tab.text,
				slotNumber: tab.getAttribute(tabContentPositionAttribute),
			},
		});
	}
}

export default class TabControl {
	private readonly hashManager: HashManager;
	private readonly suspendContentFunction: (content: HTMLDivElement) => void;
	private readonly logPageTagFactory: () => Record<string, TabConfigLog>;

	private readonly id: string;
	private readonly hasTargeting: boolean;

	private readonly headerContainer: HTMLDivElement;
	private readonly headerTabs: NodeListOf<HTMLAnchorElement>;

	private readonly contents: NodeListOf<HTMLDivElement>;

	constructor(
		hashManager: HashManager,
		suspendContentFunction: (content: HTMLDivElement) => void,
		logPageTagFactory: () => Record<string, TabConfigLog>,
		container: HTMLDivElement) {

		this.hashManager = hashManager;
		this.suspendContentFunction = suspendContentFunction;
		this.logPageTagFactory = logPageTagFactory;

		this.id = container.id;
		this.hasTargeting =
			container.getAttribute('tab-control-with-os-targeting') === 'true' ||
			container.getAttribute('tab-control-with-office-version-targeting') === 'true' ||
			container.getAttribute('tab-control-with-windows-version-targeting') === 'true';

		this.headerContainer = container.querySelector<HTMLDivElement>('div.supTabControlHeader');
		this.headerTabs = this.headerContainer.querySelectorAll<HTMLAnchorElement>('a.supTabControlTabHeader');
		this.contents = container.querySelectorAll<HTMLDivElement>('div.supTabControlTabContent');

		// NodeList.forEach is not supported in IE, use normal array loop
		for (let i = 0; i < this.headerTabs.length; i++) {
			const tab = this.headerTabs[i];
			const tabHash = tab.getAttribute('tab-hash');

			tab.addEventListener('click', e => {
				e.stopPropagation();

				// update hash in URL (triggers tab switch)
				this.hashManager.appendHashElement(tabHash);

				logAction(this.logPageTagFactory(), tab, e.type);
			});

			this.hashManager.addHashElementCallback(tabHash, () => {
				this.selectTab(tab);

				// Refresh card carousel components within the tab control's tab content.
				$(`.supTabControlTabContent ${cardContainerSelector}`).slick?.('refresh');
			});
		}
	}

	getTabConfigLogObject(this: TabControl): TabConfigLog {
		return {
			name: this.headerContainer.querySelector<HTMLAnchorElement>(`a.${activeTabClass}`).text,
			activetab: this.headerContainer.getAttribute(headerContainerActiveTabAttribute),
			defaulttab: this.headerContainer.getAttribute('ms.defaulttab'),
			istargeted: `${this.id},${this.hasTargeting}`,
		}
	}

	private selectTab(this: TabControl, selectedTab: HTMLAnchorElement) {
		// XSL position() is 1-indexed, decrement to 0-indexed
		const selectedIndex = parseInt(selectedTab.getAttribute(tabContentPositionAttribute), 10) - 1;

		// NodeList.forEach is not supported in IE, use normal array loop
		for (let i = 0; i < this.headerTabs.length; i++) {
			const tab = this.headerTabs[i];

			if (tab !== selectedTab) {
				tab.setAttribute('aria-selected', 'false');
				tab.classList.remove(activeTabClass);
			}
		}

		// NodeList.forEach is not supported in IE, use normal array loop
		for (let i = 0; i < this.contents.length; i++) {
			if (i !== selectedIndex) {
				const content = this.contents[i];
				this.suspendContentFunction(content);
				content.classList.add(hiddenClass);
			}
		}

		selectedTab.setAttribute('aria-selected', 'true');
		selectedTab.classList.add(activeTabClass);
		this.contents.item(selectedIndex).classList.remove(hiddenClass);

		// update ms.activetab attribute
		const targetingValue = selectedTab.getAttribute('targeted-office-version')
			?? selectedTab.getAttribute('targeted-os')
			?? selectedIndex + 1;

		this.headerContainer.setAttribute(headerContainerActiveTabAttribute, `${this.id},${targetingValue}`);
	}
}
