// Copyright (C) Microsoft Corporation. All rights reserved.
// requires JS and CSS from slick-carousel npm to be loaded on page

import { VideoPlayerElementName } from './VideoPlayerManager';
import type VideoPlayerManager from './VideoPlayerManager';
import { videoAreaSelector } from "../VideoCarouselModal/VideoCarouselModal";
import type { UniversalMediaPlayer } from "universal-media-player";

const scrollSpeedMs = 400;
const buttonDisabledClass = 'supCardControlCarouselDisabledButton';
const carouselClass = 'supCardControlCarousel';
const prevButtonSelector = '.supCardControlCarouselPrevButton';
const nextButtonSelector = '.supCardControlCarouselNextButton';
const allButtonSelector = `${prevButtonSelector}, ${nextButtonSelector}`;

function toggleButtons(container: HTMLDivElement, enable: boolean) {
	$(container).children(allButtonSelector).toggleClass(buttonDisabledClass, !enable);
}

export const cardContainerSelector = '.supCardControlContainer';
export const cardSelector = '.supCardControlCard';

export const heroCardContainerSelector = '.heroCardControlContainer';
export const heroCardSelector = '.heroCardControlCard';

export function initializeCardCarousel(element: HTMLDivElement, videoPlayerManager: VideoPlayerManager) {
	// assumes document direction is equal to content direction
	// existing BUG: does not work with RTL markets with fallback LTR content
	const rtl = element.ownerDocument.dir === 'rtl';
	const root = $(element);

	const breakpoints = [
		{
			breakpoint: 900,
			settings: {
				slidesToShow: 3,
				slidesToScroll: 1,
			},
		},
		{
			breakpoint: 768,
			settings: {
				slidesToShow: 2,
				slidesToScroll: 1,
			},
		},
		{
			breakpoint: 480, 
			settings: {
				slidesToShow: 1,
				slidesToScroll: 1,
			},
		},
	];

	root.children(cardContainerSelector).eq(0).slick({
		accessibility: true,
		slidesToShow: 4,
		slidesToScroll: 1,
		infinite: false,
		arrows: true,
		speed: scrollSpeedMs,
		prevArrow: root.children(prevButtonSelector),
		nextArrow: root.children(nextButtonSelector),
		rtl: rtl,
		responsive: breakpoints
	}).on('breakpoint', (_e, slick) => {
		$(slick.$slides).each((_i, slide: HTMLElement) => {
			setupVideoCarousel.call(slide);
			videoPlayerManager.setupVideo(slide.querySelector<UniversalMediaPlayer>('universal-media-player'));
		});
	}).find(cardSelector).each(setupVideoCarousel);

	root.children(heroCardContainerSelector).eq(0).slick({
		accessibility: false,
		infinite: false,
		arrows: true,
		speed: scrollSpeedMs,
		prevArrow: root.children(prevButtonSelector),
		nextArrow: root.children(nextButtonSelector),
		rtl: rtl
	});

	setupCarouselNavigationButtons(element);
}

function handleEvent(event: Event) {
	const cardContainer = event.currentTarget as HTMLElement;

	const target = event.target as HTMLElement;

	const videoPlayerContainer = cardContainer.querySelector(videoAreaSelector);

	if (videoPlayerContainer && !videoPlayerContainer.contains(target)) {
		const player = videoPlayerContainer.querySelector<UniversalMediaPlayer>(VideoPlayerElementName);
		if (player) {
			videoPlayerContainer.removeAttribute('hidden');
			player.play();
		}
	}
}

function setupVideoCarousel(this: HTMLElement) {
	const player = this.querySelector<UniversalMediaPlayer>(VideoPlayerElementName);

	// workaround to reinitialize player options since slick detaches the already-initalized UMP element
	// and reattaches the subtree, and the UMP element does not function after reattachment
	const newPlayer = document.createElement(VideoPlayerElementName);
	window.ump(newPlayer, player.options);
	player.replaceWith(newPlayer);
	player.dispose();

	this.addEventListener('click', (event) => {
		if (!isModalOpen()) {
			handleEvent(event);
		}
	});
	this.addEventListener('keypress', (event) => {
		if ((event.key === 'Enter' || event.key === ' ') && !isModalOpen()) {
			handleEvent(event);
		}
	});
}

function isModalOpen(): boolean {
	return document.querySelector('.modalContainer') !== null;
}

export function updateDots(selector: string) {
	$(selector).on('setPosition', function (_, slick: any) {
		const dots = slick.$dots;
		slick.options?.slidesToShow < slick.slideCount ? dots.show() : dots.hide();
	});
} 

export function assignFocus(carousel: JQuery<HTMLElement>, pressedButton: HTMLButtonElement) {
	const cards = carousel.find(cardSelector);
	const isNextButton = pressedButton.classList.contains(nextButtonSelector.substring(1, nextButtonSelector.length));
	const activeCard = isNextButton ? cards.filter('.slick-active').last() : cards.filter('.slick-active').first();

	if (activeCard.length > 0) {
		activeCard.focus();
	}
}

function assignHeroFocus(cards: JQuery<HTMLElement>) {
	const activeCard = cards?.filter('.slick-active')?.first();
	const activeElement = activeCard?.find('a, input, button, select')?.first();

	if (activeElement.length > 0) {
		activeElement.focus();
	}
}

function updateHeroSection(wrapper: HTMLElement, backgroundUrl: string) {
	if (wrapper) {
		wrapper.style.backgroundImage = backgroundUrl === "" ? 'none' : `url(${backgroundUrl})`;
		wrapper.classList.add('heroCarouselSection');
	}
}

function toggleTooltip(button: JQuery<HTMLElement>, event: JQuery.Event, selector: string) {
	var tooltipElement = button.find(selector);
	if (tooltipElement.length) {
		const isVisible = event.type === 'focus' || event.type === 'mouseenter';
		tooltipElement.css({
			visibility: isVisible ? 'visible' : 'hidden',
			opacity: isVisible ? '1' : '0'
		});
	}
}

function setupCarouselNavigationButtons(carousel: HTMLDivElement) {
	var slickButtons = $(carousel).find<HTMLButtonElement>(allButtonSelector);
	$(slickButtons).on('click', function (event) {
		$(carousel).one('beforeChange', function (this: HTMLDivElement) {
			toggleButtons(this, false);
		}).one('afterChange', function (this: HTMLDivElement) {
			if (carousel.classList.contains(carouselClass)) {
				assignFocus($(this), event.target);
			} else {
				assignHeroFocus($(this)?.find(heroCardSelector));
			}
			toggleButtons(this, true);
		});
	});
}

export function showTooltip(selector: string) {
	const nextButton = $(nextButtonSelector, $(selector));
	const prevButton = $(prevButtonSelector, $(selector));

	nextButton.on('focus blur mouseenter mouseleave', function (event) {
		toggleTooltip(nextButton, event, '.nextButtonTooltip');
	});
	prevButton.on('focus blur mouseenter mouseleave', function (event) {
		toggleTooltip(prevButton, event, '.prevButtonTooltip');
	});
}

export function assignBackgroundImage(elements: HTMLCollectionOf<HTMLDivElement>, selector: string) {
	const wrapper = document.querySelector(selector)?.closest('.no-wrapper') as HTMLElement;
	const initialBackgroundUrl = elements[0].querySelector('.slick-active').getAttribute('backgroundimage');

	updateHeroSection(wrapper, initialBackgroundUrl);

	$(elements).on('beforeChange', function (_event: JQuery.Event, slick: any, _currIndex: number, nextIndex: number) {
		updateHeroSection(wrapper, slick.$slides.eq(nextIndex)?.attr('backgroundimage'));
	});
}
