// Copyright (C) Microsoft Corporation. All rights reserved.

export enum DataBoundary {
	None = 'None',
	EU = 'EU'
}

export enum UserAgeGroup {
	Undefined,
	MinorWithoutParentalConsent,
	MinorWithParentalConsent,
	Adult,
	NotAdult,
	MinorNoParentalConsentRequired,
}

export interface MeControlAccount {
	type: string,
	tenantId: string,
	memberName: string,
	displayName: string,
	firstName: string,
	lastName: string,
	authenticatedState: string
}

export interface SilentSignInProperties {
	account: MeControlAccount,
	userIsChild?: boolean,
	localTelemetryId: string,
	telemetryAuthType: string,
	puid: string,
	authType: string,
	dataBoundary: string,
	ageGroup?: UserAgeGroup
}

export type MsShellObj = {
	meControlOptions: { currentAccount: MeControlAccount }
}

export interface IMsCommonShell {
	load: (msShellCurrentAccount: MsShellObj) => Promise<void>;
	meControlOptions: () => { currentAccount: MeControlAccount };
}

// Value Guidance Types
export interface ISignInCompletionObj {
	eventType: string,
	authType?: string,
	dataBoundary?: DataBoundary,
	meControlAccount?: MeControlAccount
}
