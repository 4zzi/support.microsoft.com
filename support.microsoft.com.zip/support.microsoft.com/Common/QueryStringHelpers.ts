// Copyright (C) Microsoft Corporation. All rights reserved.

import 'core-js/features/url';
import 'core-js/features/url-search-params';

export const getQueryString = (key: string, location: Location = window.location): string => {
	const params = new URLSearchParams(location.search);
	return params.get(key) ?? '';
};

export const setQueryString = (key: string, value: string, url: string = window.location.href): string => {
	let u = new URL(url);
	u.searchParams.set(key, value);
	return u.href;
};
