// Copyright (C) Microsoft Corporation. All rights reserved.

export interface CaptureContentEventProperties {
	actionType: string,
	content: {
		[key: string]: string
	},
	pageTags?: {
		[key: string]: string
	},
	isManual?: boolean
}

export function LogContentUpdateEvent(properties: CaptureContentEventProperties, behavior: BehaviorType) {
	if (typeof (<any>window).top.analytics === 'object') {
		properties['behavior'] = (<any>window).top?.oneDS?.Behavior[behavior];
		(<any>window).top?.analytics?.captureContentUpdate(properties);
	};
}

export enum BehaviorType {
	Impression = 'IMPRESSION',
	SignIn = 'SIGNIN'
}
