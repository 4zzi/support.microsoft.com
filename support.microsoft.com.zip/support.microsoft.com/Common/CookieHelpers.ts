// Copyright (C) Microsoft Corporation. All rights reserved.

/* eslint "@microsoft/sdl/no-cookies": "off" */

export const getCookie = (name: string): string | null => {
	for (const cookie of document.cookie.split('; ')) {
		const kvp = cookie.split('=');
		if (kvp[0] === name) {
			return decodeURIComponent(kvp[1]);
		}
	}

	return null;
};

export const setCookie = (name: string, value: string, maxAgeMilliseconds?: number) => {
	let cookie = `${name}=${value};path=/`;
	if (maxAgeMilliseconds !== undefined) {
		const expires = new Date(Date.now() + maxAgeMilliseconds);
		cookie += `;expires=${expires.toUTCString()}`;
	}

	document.cookie = cookie;
};
