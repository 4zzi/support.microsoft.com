// Copyright (C) Microsoft Corporation. All rights reserved.
import type { ApplicationInsights, IPageActionOverrideValues } from "@microsoft/1ds-analytics-web-js";
import { setCarouselVideoModal } from '../VideoCarouselModal/VideoCarouselModal';
import type { UniversalMediaPlayer, ump } from "universal-media-player";

interface IVideoEventMessage {
	videoId?: string;
	currentTime?: number;
	duration?: number;
	title?: string;
}

declare global {
	interface Window {
		analytics?: ApplicationInsights;
		ump: typeof ump;
	}
}

export const VideoContainerClassName = 'ocpVideo';
export const VideoContainerSelector = `div.${VideoContainerClassName}`;
export const VideoIdDataPropertyName = 'videoid';
export const VideoTitleDataPropertyName = 'videotitle';
export const VideoPlayerElementName = 'universal-media-player';

export default class VideoPlayerManager {
	private readonly useNarrowWidth: boolean;
	private static videoEventNameToBehavior: Map<string, number> = new Map([
		['play', 240],
		['pause', 241],
		['resume', 242],
		['timeupdate', 243],
		['seeked', 244],
		['ended', 245],
		['waiting', 246],
		['error', 247],
		['mute', 248],
		['unmute', 249],
		['fullscreenenter', 250],
		['fullscreenexit', 251],
		['canplay', 253]
	]);
	private static autoEmittedEvents = new Set(['pause', 'timeupdate', 'seeked', 'waiting', 'canplay', 'ended', 'error', 'mute', 'unmute']);

	constructor(
		useNarrowWidth: boolean) {
		this.useNarrowWidth = useNarrowWidth;
	}

	setupVideo(this: VideoPlayerManager, element: UniversalMediaPlayer) {
		this.setupEventListeners(element, element.parentElement.id);
	}

	setupVideos(this: VideoPlayerManager, document: Document) {
		document.querySelectorAll<UniversalMediaPlayer>(VideoPlayerElementName).forEach(player => this.setupVideo(player));
	}

	pauseVideos(this: VideoPlayerManager, element: HTMLElement) {
		element.querySelectorAll<UniversalMediaPlayer>(VideoPlayerElementName).forEach(player => player.pause());
	}

	pauseAllVideosExcept(this: VideoPlayerManager, id: string) {
		document.querySelectorAll<UniversalMediaPlayer>(VideoPlayerElementName).forEach(player => {
			if (player.parentElement.id !== id) {
				player.pause();
			}
		});
	}

	private setupEventListeners(umpPlayer: UniversalMediaPlayer, id: string) {
		for (const [event] of VideoPlayerManager.videoEventNameToBehavior) {
			if (event === 'play') {
				this.addEvent(umpPlayer, 'play', () => {
					const { currentTime } = umpPlayer.currentState;
					const eventName = currentTime === 0 ? 'play' : 'resume';
					this.onMessageReceived(eventName, id, umpPlayer.currentState);
				});
			}
			if (VideoPlayerManager.autoEmittedEvents.has(event)) {
				this.addEvent(umpPlayer, event, () => this.onMessageReceived(event, id, umpPlayer.currentState));
			}
		}
		this.addEvent(umpPlayer, 'canplay', () => {
			this.addEvent(document, 'fullscreenchange', () => {
				if (document.fullscreenElement) {
					this.onMessageReceived('fullscreenenter', id, umpPlayer.currentState);
				} else {
					this.onMessageReceived('fullscreenexit', id, umpPlayer.currentState);
				}
			});
		});
	}

	private addEvent(element: EventTarget, eventName: string, eventHandler: EventListener): void {
		element.addEventListener(eventName, eventHandler, false);
	}

	private sanitize(input: string): string {
		const map: { [key: string]: string } = {
			'&': '&amp;',
			'<': '&lt;',
			'>': '&gt;',
			'"': '&quot;',
			"'": '&#x27;',
			'/': '&#x2F;',
			'`': '&#x60;',
			'=': '&#x3D;'
		};
		const reg = /[&<>"'/`=]/ig;
		return input.replace(reg, (match) => map[match]);
	}

	private onMessageReceived = (eventName: string, videoId: string, e: IVideoEventMessage): void => {
		let message: IVideoEventMessage;
		const umpVideoId = e.videoId ?? (document.getElementById(videoId) as HTMLElement).dataset[VideoIdDataPropertyName];
		try {
			message = {
				videoId: this.sanitize(umpVideoId),
				currentTime: e.currentTime,
				duration: e.duration,
				title: this.sanitize(e.title)
			};
		} catch (err) {
			// The error will be detected in the following 'if' block
		}
		
		if (!message || typeof message !== 'object') {
			return;
		}

		if (!VideoPlayerManager.videoEventNameToBehavior.has(eventName)) {
			return;
		}

		//the content tags as they exist today, commented out are properties which cannot be computed currently or whose value is unknown
		let contentTags: any = {
			vidnm: '',
			vidid: '',
			vidpct: 0,
			//vidpctwtchd: 0, seems to be video watch % over a session 
			vidwt: 0,
			viddur: 0,
			vidtimeseconds: 0,
			//sessiontimeseconds: 0, seems to be video watch time over a session
			live: false,
			//parentpage: '', shouldn't be relevant since our page tags will account for the page name
			containerName: 'umpplayer',
			// dlid: '', download media, not captured in video event
			// dltype: '', download type, not captured in video event 
			// socchn: '', realted to video shares which involve inspecting the iframe, we get the event but there isn't a behavior map
			// name: '', comes from extra reporting data that we don't have access to
			id: ''
		};

		const currVideo = document.querySelector(`#${videoId} universal-media-player`).closest('.ocpVideo');
		this.populateContentTags(contentTags, message.title, message.videoId, message.duration, message.currentTime);
		let pageOverride: IPageActionOverrideValues = {
			actionType: 'O',
			behavior: VideoPlayerManager.videoEventNameToBehavior.get(eventName),
			content: contentTags,
			isAuto: false
		};
		let videoContainerDivId = currVideo.id;
		window.analytics?.capturePageAction(document.getElementById(videoContainerDivId), pageOverride);
		this.updateVideoCarouselModal(eventName, videoContainerDivId);
	};

	private updateVideoCarouselModal(eventName: string, videoContainerDivId: string) {
		var $videoElement = $("#" + videoContainerDivId);
		if ($videoElement.length <= 0 || $videoElement.closest('.slick-list').length <= 0) {
			return;
		}
		if (eventName === 'play' || eventName === 'resume') {
			this.pauseAllVideosExcept(videoContainerDivId);
			setCarouselVideoModal($videoElement.closest('.supCardControlCard'));
		}
	}

	private populateContentTags(contentTag: any, title: string, videoId: string, duration: number, currTime: number) {
		contentTag.vidnm = title;
		contentTag.vidid = videoId;
		contentTag.viddur = Math.round(duration);
		contentTag.vidwt = Math.round(currTime);
		contentTag.vidtimeseconds = Math.round(duration);
		contentTag.id = `videoMetaData_${videoId}`;

		var vidPercent = 0;
		if (duration > 0) {
			vidPercent = Math.round(100 * (currTime / duration));
		}
		contentTag.vidpct = vidPercent;
	}
}
