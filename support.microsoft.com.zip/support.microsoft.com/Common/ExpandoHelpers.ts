// Copyright (C) Microsoft Corporation. All rights reserved.

import type VideoPlayerManager from './VideoPlayerManager';
import type { ApplicationInsights, Behavior } from '@microsoft/1ds-analytics-web-js';

declare global {
	interface Window {
		analytics?: ApplicationInsights;
		oneDS: {
			Behavior: typeof Behavior;
		};
	}
}

const iconClasses = ['ms-Icon--expandoCollapsed', 'ms-Icon--expandoExpanded'];
const openedClass = 'opened';
const slideTimeMs = 150;

function logExpandoClick(button: HTMLButtonElement, isOpening: boolean) {
	const analytics = window.analytics;

	if (analytics) {
		analytics.capturePageAction(null, {
			actionType: 'CL',
			behavior: isOpening ? window.oneDS.Behavior.EXPAND : window.oneDS.Behavior.REDUCE,
			contentTags: {
				'contentName': button.innerText.trim(),
				'areaName': 'expando',
				'slotNumber': button.dataset['biSlot'],
			}
		});
	}
}

export const setupExpandos = (headSelector: string, bodySelector: string, videoPlayerManager: VideoPlayerManager) => {
	const expandoHeaders = $(headSelector);

	expandoHeaders.find('button')
		.attr('data-bi-mto', '')
		.attr('data-bi-slot', index => index + 1);

	expandoHeaders.click(e => {
		e.preventDefault();

		const expandoHead = $(e.delegateTarget);
		const expandoBodyWrapper = expandoHead.next();

		const isOpened = expandoHead.hasClass(openedClass);

		if (isOpened) {
			videoPlayerManager.pauseVideos(expandoBodyWrapper[0]);
		}

		expandoHead.toggleClass(openedClass);

		expandoBodyWrapper.find(bodySelector).slideToggle(slideTimeMs);
		expandoHead.find('i').toggleClass(iconClasses);

		const button = expandoHead.find('button').attr('aria-expanded', (!isOpened).toString());
		logExpandoClick(button[0], !isOpened);
	});
}
