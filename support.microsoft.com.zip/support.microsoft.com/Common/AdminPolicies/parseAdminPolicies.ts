// Copyright (C) Microsoft Corporation. All rights reserved.

import { AdminPolicy } from './types';
import { TenantAdminPoliciesElementId } from '../Strings';


export function parseAdminPolicies(element?: HTMLElement): AdminPolicy {
	return parseAdminPoliciesInternal(element ?? document.getElementById(TenantAdminPoliciesElementId));
}


function parseAdminPoliciesInternal(element: HTMLElement): AdminPolicy {
	const jsonPayload = element?.dataset.settings;

	if (jsonPayload) {
		return JSON.parse(jsonPayload) as AdminPolicy;
	}

	return null;
}
