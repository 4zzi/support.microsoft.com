// Copyright (C) Microsoft Corporation. All rights reserved.

export const getSessionStorage = (key: string): string | null => {
	try {
		return sessionStorage.getItem(key);
	} catch (_) { }

	return null;
};

export const trySetSessionStorage = (key: string, value: string, overwrite: boolean = false): boolean => {
	if (!overwrite && getSessionStorage(key) !== null) {
		return false;
	}

	try {
		sessionStorage.setItem(key, value);
	} catch (_) {
		return false;
	}

	return true;
};
