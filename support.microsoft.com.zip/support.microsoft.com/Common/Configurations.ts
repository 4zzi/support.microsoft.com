// Copyright (C) Microsoft Corporation. All rights reserved.
/**
 * @file Scripts/Common/Configurations.ts
 * @fileoverview Configurations module for the SupportService project.
 * @module Configurations
 * @description This module contains configurations for the SupportService project.
 */

/**
 * Configuration for the Contact Us links.
 */
export const ContactUsLinkConfigurations = [
	{
		selector: '#articleFooterSupportBridge a[href$="/contactus"]', // Selector for the Contact Us link in the article footer
		attributes: {
			'data-bi-bhvr': 'CALL',
			'data-bi-id': 'authoredBridgeContactUs',
		},
	},
	{
		selector: '#footerArea a[href$="/contactus"]', // Selector for the Contact Us link in the site footer
		attributes: {
			'data-bi-bhvr': 'CALL',
		},
	},
]
