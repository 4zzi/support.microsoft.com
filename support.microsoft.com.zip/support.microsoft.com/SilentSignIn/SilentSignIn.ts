// Copyright (C) Microsoft Corporation. All rights reserved.

import { SetMeControlAccount } from "../Common/Helpers";
import { SilentSignInProperties } from '../Common/AuthenticationTypes';
import { CaptureContentEventProperties, LogContentUpdateEvent, BehaviorType } from '../Common/Logging';

export function HandleSilentSignIn(silentSignInProperties: SilentSignInProperties, isUserAuthenticated: boolean) {
	DispatchSilentSignInAttemptedEvent(silentSignInProperties);

	if (!isUserAuthenticated) {
		var captureEvent: CaptureContentEventProperties = {
			isManual: true,
			actionType: 'A',
			content: { contentId: 'silentSignInFailed', authProvider: silentSignInProperties.authType, multiAttempt: IsSilentSignInReAttempt().toString() }
		};
		LogContentUpdateEvent(captureEvent, BehaviorType.Impression);
		return;
	}

	SetMeControlAccount(silentSignInProperties.account, (<any>window).parent);

	if (silentSignInProperties?.localTelemetryId) {
		(<any>window)?.top?.analytics?.getPropertyManager()?.getPropertiesContext()?.user?.setLocalId(silentSignInProperties.localTelemetryId);
	}

	var captureEvent: CaptureContentEventProperties = {
		actionType: 'A',
		content: { contentId: 'silentSignInSucceeded', autoAuth: 'true', authProvider: silentSignInProperties.authType, multiAttempt: IsSilentSignInReAttempt().toString() },
		pageTags: { authtype: silentSignInProperties.telemetryAuthType, tenantId: silentSignInProperties.account.tenantId }
	}

	LogContentUpdateEvent(captureEvent, BehaviorType.SignIn)

	if (silentSignInProperties.userIsChild) {
		window.parent.document.getElementById('supWrapperToPreventFeedbackFlickering')?.remove();
	}
}

function IsSilentSignInReAttempt() {
	const silentSignInIframe = (<HTMLIFrameElement>window.top.document.getElementById('iframeOP'));
	return silentSignInIframe?.getAttribute('isduplicateattempt') === 'true';
}

function DispatchSilentSignInAttemptedEvent(signInProperties: SilentSignInProperties) {
	window.silentSigninProgress = true;
	const eventType = 'silentSignInAttempted';
	const silentSignInAttemptedEvent = new CustomEvent(eventType, {
		detail: { ...signInProperties },
		bubbles: true,
		cancelable: false
	});

	window.top.document.dispatchEvent(silentSignInAttemptedEvent);
}
