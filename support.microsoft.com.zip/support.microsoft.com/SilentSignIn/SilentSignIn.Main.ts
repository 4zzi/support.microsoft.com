// Copyright (C) Microsoft Corporation. All rights reserved.

import { HandleSilentSignIn } from './SilentSignIn';
import { parseAdminPolicies } from '../Common/AdminPolicies/parseAdminPolicies';
import { TenantAdminPoliciesElementId } from '../Common/Strings';

//Webpack will tree shake this function unless it is used somewhere in the source files.
(<any>window).CurrentSilentSignInAttempt = HandleSilentSignIn;

propagateTenantAdminPoliciesToMainWindow();


function propagateTenantAdminPoliciesToMainWindow(): void {
	try {
		var adminPolicy = parseAdminPolicies();

		if (!adminPolicy) {
			return;
		}

		const parentPolicyDataModelElement = window.top.document.getElementById(TenantAdminPoliciesElementId);

		if (parentPolicyDataModelElement) {
			parentPolicyDataModelElement.setAttribute("data-settings", JSON.stringify(adminPolicy));
		}
		else {
			var policyDataModelElement = window.top.document.createElement("div");
			policyDataModelElement.id = TenantAdminPoliciesElementId;
			policyDataModelElement.setAttribute("data-settings", JSON.stringify(adminPolicy));
			window.top.document.body.appendChild(policyDataModelElement);
		}
	}
	catch (err) {
		console.error(err);
	}
}
