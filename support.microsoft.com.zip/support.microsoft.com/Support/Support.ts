// Copyright (C) Microsoft Corporation. All rights reserved.

import * as Constants from '../Common/Constants';
import { ContactUsLinkConfigurations } from '../Common/Configurations';
import { getCookie, setCookie } from '../Common/CookieHelpers';
import * as EventHelpers from '../Common/EventHelpers';
import { setupExpandos } from '../Common/ExpandoHelpers';
import { scheduleImmediateCallback } from '../Common/FunctionScheduler';
import { getMetaTagValue, setMetaTag, refreshTelemetryMetadata } from '../Common/MetaTagHelpers';
import { getQueryString, setQueryString } from '../Common/QueryStringHelpers';
import ResourceManager from '../Common/ResourceManager';
import { getSessionStorage, trySetSessionStorage } from '../Common/StorageHelpers';
import VideoPlayerManager from '../Common/VideoPlayerManager';
import VideoCarouselManager from '../Common/VideoCarouselManager';

const previousAssetIdKey = 'prevAssetDKey';

export default class Support {
	private readonly videoPlayerManager: VideoPlayerManager;
	private readonly videoCarouselManager: VideoCarouselManager;
	readonly assetId: string | undefined;
	readonly Controls: {
		Carousel: {
			// jQuery each() callback function binds `this` to the current element
			setupCarousel: (
				this: HTMLUListElement,
				index: number,
				element: HTMLUListElement) => void;
		}
	}

	constructor() {
		this.assetId = getMetaTagValue('ms.ocpub.assetID');
		this.videoPlayerManager = new VideoPlayerManager(
			navigator.platform.toLowerCase().indexOf('ipad') > -1);

		this.videoCarouselManager = new VideoCarouselManager(this.videoPlayerManager);

		// bind into closure
		let videoCarouselManager = this.videoCarouselManager;

		this.Controls = {
			Carousel: {
				setupCarousel: function (
					this: HTMLUListElement,
					_: number,
					element: HTMLUListElement) {
					videoCarouselManager.setupCarousel(element);
				}
			}
		};
	}

	constants = {
		events: Constants.eventConstants,
		fadeInTimeoutMs: Constants.styleTransitionMs,
		wedcs: Constants.wedcsConstants,
	};
	eventHelpers = EventHelpers;
	pushOntoExecutionStack = scheduleImmediateCallback;
	getMetaTagValue = getMetaTagValue;
	setMetaTag = setMetaTag;
	update1dsMetaTagTelemetry = refreshTelemetryMetadata;
	GetQueryStringParam = getQueryString;
	updateQueryStringParameter = setQueryString;
	GetCookie = getCookie;
	SetCookie = setCookie;
	GetSessionValue = getSessionStorage;
	TrySetSessionValue = trySetSessionStorage;

	Resources = new ResourceManager();

	setPreviousAssetId() {
		const previousAssetId = getSessionStorage(previousAssetIdKey);
		if (previousAssetId !== null) {
			setMetaTag('ms.ocpub.previousassetID', previousAssetId);
		}
	}

	setSessionAssetValue(this: Support) {
		if (this.assetId?.toLowerCase().indexOf('s.cl.nav') === -1) {
			trySetSessionStorage(previousAssetIdKey, this.assetId, true);
		}
	}

	bindExpando(this: Support, headSelector: string, bodySelector: string) {
		setupExpandos(headSelector, bodySelector, this.videoPlayerManager);
	}

	/**
	 * Initializes features that depend on the DOM being loaded.
	 */
	initializeDomDependentFeatures(): void {
		this.updateDomContactUsLinkTracking();
		this.updateDomDataBiNameOnAnchorsWithImages();

		// Add additional DOM-dependent fuctions here...
	}

	/**
	 * Ensures the 'Contact Us' links include the asset ID for entry point tracking.
	 */
	private updateDomContactUsLinkTracking(): void {
		try {
			ContactUsLinkConfigurations.forEach((config) => {
				document.querySelectorAll<HTMLAnchorElement>(config.selector).forEach(anchor => {
					const updatedHref = this.updateQueryStringParameter(
						'ContactUsExperienceEntryPointAssetId',
						this.assetId,
						anchor.getAttribute('href') || ''
					);

					anchor.setAttribute('href', updatedHref);
					Object.keys(config.attributes).forEach(attr => {
						anchor.setAttribute(attr, config.attributes[attr]);
					});
				});
			});
		} catch (error) {
			console.error('Error updating Contact Us links with asset ID:', error);
		}
	}

	/**
	 * Ensures the 'data-bi-name' attribute is set on all anchors containing images.
	 */
	private updateDomDataBiNameOnAnchorsWithImages(): void {
		try {
			// Select all anchor (`<a>`) elements that contain an image (`<img>`)
			const anchorsWithImages = document.querySelectorAll<HTMLAnchorElement>('a img:first-of-type');

			anchorsWithImages.forEach(img => {
				// Find the closest anchor element to the image
				const anchor = img.closest('a');

				// If the anchor element exists and does not already have a 'data-bi-name' attribute
				if (anchor && !anchor.hasAttribute('data-bi-name')) {
					const altText = img.getAttribute('alt') || '';
					// Set the 'data-bi-name' attribute to the image's 'alt' text
					anchor.setAttribute('data-bi-name', altText);
				}
			});
		} catch (error) {
			console.error(`Error updating 'data-bi-name' on anchors with images:`, error);
		}
	}

	/**
	 * Sets up the videos on the page
	 * @param {Support} this - The Support object
	 * 
	 */
	setupVideosOnPage(this: Support): void {
		// this is a fire-and-forget promise
		this.videoPlayerManager.setupVideos(document);
	}

	getVideoPlayerManager() {
		return this.videoPlayerManager;
	}

	suspendStateOfContents(this: Support, elements: JQuery<HTMLElement>) {
		elements.each((_, element) => this.videoPlayerManager.pauseVideos(element));
	}

	windowIsTabletSizeOrSmaller() {
		return document.documentElement.clientWidth <= 768;
	}
}
