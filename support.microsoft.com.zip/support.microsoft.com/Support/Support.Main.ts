// Copyright (C) Microsoft Corporation. All rights reserved.

import Support from './Support';
import { eventConstants } from '../Common/Constants';
import { copyElementContents } from '../Common/ClipboardHelpers';
import { logCopyEvent } from '../Common/LogCopyEvent';
import { isUserAuthenticated } from "../Common/Helpers";

declare global {
	interface Window {
		occe: Support
	}
	interface String {
		format?: (this: String, ...args) => String
	}
}

// extend string prototype with format function (used by cardControl.js in article JS bundle)
(() => {
	if (String.prototype.format === undefined) {
		String.prototype.format = function (this: String, ...args) {
			return this.replace(/{(\d+)}/g, (_, numberString) =>
				args[numberString] !== undefined ? args[numberString] : numberString);
		};
	}
})();

window.occe = new Support();

$(() => {
	document.addEventListener(eventConstants.COPY_EVENT_TYPE, logCopyEvent);

	// setup expando handler (moved from immediate execution during script parse to start of ready event)
	window.occe.bindExpando('.ocpExpandoHead', '.ocpExpandoBody');

	window.occe.setPreviousAssetId();
	window.occe.setSessionAssetValue();

	window.document.addEventListener('silentSignInComplete', function (e: CustomEvent) {
		let authType: string = e.detail['authType'];
		let isUserAuthed = isUserAuthenticated(authType);
		let accountDetails = e.detail['account'];

		if (isUserAuthed && accountDetails) {
			const authedElem = document.getElementById('document_toBeSwitchedOnAuth');
			if (authedElem) {
				const spanElems = authedElem.querySelectorAll('span');
				for (var i = 0; i < spanElems.length; i++) {
					const userProperty: string = spanElems[i].dataset['userProperty'];

					if (userProperty === "GivenName") {
						spanElems[i].textContent = accountDetails['firstName'];
					} else if (userProperty === "Surname") {
						spanElems[i].textContent = accountDetails['lastName'];
					}
				}

				authedElem.classList?.remove('ocHidden');
				document.getElementById('document_default_hero')?.remove();
			}

			let userLoginId: string = accountDetails['memberName'];
			if (typeof userLoginId !== null && userLoginId !== '') {
				$('a[href*="answers.microsoft.com"]')
					.attr('href', (_, value) =>
						window.occe.updateQueryStringParameter('login_hint', userLoginId, value));
			}
		}
	});

	// seed UHF search box with query string
	const query = window.occe.GetQueryStringParam('query');
	if (query !== '') {
		$('#cli_shellHeaderSearchInput').val(query);
	}

	$('ul.ocpCarousel').each(window.occe.Controls.Carousel.setupCarousel);

	$('button.copy-table').click(event => {
		const table = $(event.target).prev('table').get(0);
		if (table) {
			copyElementContents(table);
		}
	});

	// search box custom click event
	$('form[action*="/search/results" i]').on("submit", function () {
		const analytics = window.analytics;

		if (analytics) {
			const tagSet = {
				actionType: 'CL',
				behavior: window.oneDS?.Behavior.SEARCH,
				contentTags: {
					'contentId': 'searchsubmit'
				}
			};

			analytics.capturePageAction(this, tagSet, null);
		}
	});
});

$(window).on('load', () => window.occe.setupVideosOnPage());

/**
 * Add event listener to initialize DOM-dependent features
 * Only include functions that do not have a dependency on JQuery.
 */
document.addEventListener('DOMContentLoaded', () => {
	window.occe.initializeDomDependentFeatures();
});
