// Copyright (C) Microsoft Corporation. All rights reserved.

import type Support from '../Support/Support';
import { eventConstants, hiddenClass } from '../Common/Constants';
import { initializeCardCarousel, assignBackgroundImage, heroCardSelector, updateDots, showTooltip } from '../Common/CardCarouselHelpers';
import HashManager from '../Common/HashManager';
import TabControl from '../Common/TabControl';
import type { TabConfigLog } from '../Common/TabControl';
import { handleAdminPolicies } from './handleAdminPolicies';
import { initializeSelectableContentOptions } from '../SelectableContentOptionsController/SelectableContentOptionsController.Main';

type ArticleExtendedSupport = Support & {
	Controls: {
		CardControl?: {
			initializeSlickCarousels: () => void,
			assignBackgroundImage: () => void,
			updateDots: (selector: string) => void,
			showToolTip: (selector: string) => void,
		},
	},
	HashManager?: {
		addHashElementCallback: (value: string, callback: Function) => void,
		appendHashElement: (value: string) => void,
	},
};

$(() => {
	document.getElementById('ocpFallbackNotificationBarCloseButtonLink')?.addEventListener(eventConstants.CLICK_EVENT_TYPE, _ => {
		document.getElementById('ocpFallbackNotificationBar').classList.add(hiddenClass);
	});

	const occe: ArticleExtendedSupport = window.occe;

	function removeIfEmpty(_: number, e: HTMLElement) {
		const element = $(e);

		if ($.trim(element.text()).length === 0 && element.find('img').length === 0) {
			element.remove();
		}
	}

	const bandedTables: JQuery<HTMLTableElement> = $('table.banded');

	// remove empty tables
	bandedTables.each(removeIfEmpty);

	// remove empty rows
	bandedTables.find('tr').each(removeIfEmpty);

	// make adjacent rows have alternate colors in a banded table have to be flipped
	// when the header cells are inside a <thead>
	bandedTables.filter((_, element) => !!element.tHead).addClass('flipColors');

	const hashManager = new HashManager();

	occe.HashManager = {
		addHashElementCallback: function (value, callback) {
			hashManager.setCallback(value, callback);
		},
		appendHashElement: function (value) {
			hashManager.append(value);

			window.history.pushState(undefined, undefined, `#${hashManager.toHashString()}`);
		},
	};

	$(window).on('hashchange', () => hashManager.replaceAll(window.location));

	const carouselClass = 'supCardControlCarousel';
	const heroCarouselClass = 'heroCardControlCarousel';

	occe.Controls.CardControl = {
		initializeSlickCarousels: function () {
			const elements = document.querySelectorAll(`.${carouselClass}, .${heroCarouselClass}`);

			elements.forEach(element => {
				initializeCardCarousel(element as HTMLDivElement, occe.getVideoPlayerManager());
			});
		},

		assignBackgroundImage: function () {
			const heroElements = <HTMLCollectionOf<HTMLDivElement>>document.getElementsByClassName(heroCarouselClass);
			assignBackgroundImage(heroElements, heroCardSelector);
		},
		updateDots: updateDots,
		showToolTip: showTooltip,
	};

	$(`.${heroCarouselClass}`).on('init', function (this: HTMLElement) {
		occe.Controls.CardControl.assignBackgroundImage();
		occe.Controls.CardControl.showToolTip(`.${heroCarouselClass}`);
	});

	occe.Controls.CardControl.initializeSlickCarousels();

	// Initialize dropdowns once the DOM is fully loaded
	initializeSelectableContentOptions();

	const tabControls = new Array<TabControl>();

	// assumes class is on div
	const tabControlElements = <HTMLCollectionOf<HTMLDivElement>>document.getElementsByClassName('supTabControl');

	function suspendTabContent(element: HTMLElement) {
		occe.suspendStateOfContents($(element));
	}

	function generateTabControlPageTags(): Record<string, TabConfigLog> {
		const tags: Record<string, TabConfigLog> = {};

		tabControls.forEach((tabControl: TabControl, index: number) => {
			tags[`tabcontrol${index}`] = tabControl.getTabConfigLogObject();
		});

		return tags;
	}

	for (let i = 0; i < tabControlElements.length; i++) {
		const tabControl = new TabControl(occe.HashManager, suspendTabContent, generateTabControlPageTags, tabControlElements[i]);
		tabControls.push(tabControl);
	}

	// process existing hash callbacks
	hashManager.replaceAll(window.location);
});

$(window).on('load', () => {
	//handle tenant admin policies
	handleAdminPolicies();

	// reduce high-res img width
	const highResolutionImages = document.querySelectorAll<HTMLImageElement>(".ocpHighResContent img");

	// NodeList.forEach is not supported in IE, use normal array loop
	for (let i = 0; i < highResolutionImages.length; i++) {
		const image = highResolutionImages[i];

		image.width = image.naturalWidth / 2;
	}
});
