// Copyright (C) Microsoft Corporation. All rights reserved.
import { parseAdminPolicies } from '../Common/AdminPolicies/parseAdminPolicies';
import { addSilentAuthEventListener } from "../Common/Auth/AuthHelpers";
import { isAadUser } from '../Common/Helpers';
import { SilentSignInProperties } from '../Common/AuthenticationTypes';

export function handleAdminPolicies(): void {
	//TODO: utilize promise from window.manageSilentSignIn
	addSilentAuthEventListener((props: CustomEvent<SilentSignInProperties | Error>) => {

		if (props.detail instanceof Error) {
			return;
		}

		const authProperties = props.detail as SilentSignInProperties;
		const aadPrivacySubtext = document.getElementById("aadPrivacySubtext");

		if (!isAadUser(authProperties.authType)) {
			aadPrivacySubtext?.remove();
			return;
		}

		// only apply policies for AAD users
		const policies = parseAdminPolicies();

		const feedbackContainer = document.getElementById("supFeedbackWrapper");
		if (!policies.AllowFeedback) {
			feedbackContainer?.remove();
			return;
		}

		// If policy enables feedback for AAD users, display disclaimer text
		if (feedbackContainer !== null) {
			aadPrivacySubtext?.classList?.remove("ocHidden");
		}
	});
}
