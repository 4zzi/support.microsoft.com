/*
 * 1DS JS SDK Properties plugin, 4.0.2
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
/**
* IntWeb.ts
* @author Hector Hernandez (hectorh)
* @copyright Microsoft 2019
*/
import dynamicProto from "@microsoft/dynamicproto-js";
import { getCookieValue, onConfigChange } from "@microsoft/1ds-core-js";
import { objDefine } from "@nevware21/ts-utils";
function _getMsfpc() {
    return this.getMsfpc();
}
function _getAnid() {
    return this.getAnid();
}
var IntWeb = /** @class */ (function () {
    function IntWeb(propertiesConfig, core, unloadHookContainer) {
        var _cookieMgr;
        dynamicProto(IntWeb, this, function (_self) {
            _populateDefaults(propertiesConfig);
            _self.getMsfpc = function () {
                return getCookieValue(_cookieMgr, "MSFPC");
            };
            _self.getAnid = function () {
                return getCookieValue(_cookieMgr, "ANON").slice(0, 34);
            };
            function _populateDefaults(config) {
                // This function will be re-called whenever any referenced configuration is changed
                var unloadHook = onConfigChange(config, function () {
                    _cookieMgr = core && core.getCookieMgr();
                    var _config = config || {};
                    if (_config.serviceName) {
                        _self.serviceName = _config.serviceName; // change serviceName only if incoming values is not null, undefined or ""
                    }
                });
                unloadHookContainer && unloadHookContainer.add(unloadHook);
            }
        });
    }
// Removed Stub for IntWeb.prototype.getMsfpc.
// Removed Stub for IntWeb.prototype.getAnid.
    /**
     * Static constructor, attempt to create accessors
     */
    IntWeb._staticInit = (function () {
        // Dynamically create get/set property accessors
        var proto = IntWeb.prototype;
        objDefine(proto, "msfpc", { g: _getMsfpc });
        objDefine(proto, "anid", { g: _getAnid });
    })();
    return IntWeb;
}());
export { IntWeb };
//# sourceMappingURL=IntWeb.js.map