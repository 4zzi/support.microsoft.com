/*
 * 1DS JS SDK Properties plugin, 4.0.2
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
/**
* Web.ts
* @author Hector Hernandez (hectorh)
* @copyright Microsoft 2019
*/
import dynamicProto from "@microsoft/dynamicproto-js";
import { getCookieValue, getLocation, getNavigator, getWindow, isArray, onConfigChange, safeGetCookieMgr } from "@microsoft/1ds-core-js";
import { isBoolean, objDefine, objDefineProps } from "@nevware21/ts-utils";
var USER_CONSENT_DETAILS = [
    "Required", "Analytics", "SocialMedia", "Advertising"
];
var REGEX_VERSION = "([\\d,.]+)";
var UNKNOWN = "Unknown";
var EDGE_CHROMIUM = "Edg/";
var USER_AGENTS = [
    { ua: "OPR/", b: "Opera" /* BROWSERS.OPERA */ },
    { ua: "PhantomJS" /* BROWSERS.PHANTOMJS */, b: "PhantomJS" /* BROWSERS.PHANTOMJS */ },
    { ua: "Edge" /* BROWSERS.EDGE */, b: "Edge" /* BROWSERS.EDGE */ },
    { ua: EDGE_CHROMIUM, b: "Edge" /* BROWSERS.EDGE */ },
    { ua: "Electron" /* BROWSERS.ELECTRON */, b: "Electron" /* BROWSERS.ELECTRON */ },
    { ua: "Chrome" /* BROWSERS.CHROME */, b: "Chrome" /* BROWSERS.CHROME */ },
    { ua: "Trident", b: "MSIE" /* BROWSERS.MSIE */ },
    { ua: "MSIE ", b: "MSIE" /* BROWSERS.MSIE */ },
    { ua: "Firefox" /* BROWSERS.FIREFOX */, b: "Firefox" /* BROWSERS.FIREFOX */ },
    { ua: "Safari" /* BROWSERS.SAFARI */, b: "Safari" /* BROWSERS.SAFARI */ },
    { ua: "SkypeShell" /* BROWSERS.SKYPE_SHELL */, b: "SkypeShell" /* BROWSERS.SKYPE_SHELL */ } // Check for Skype shell
];
var BRANDS = [
    { br: "Microsoft Edge", b: "Edge" /* BROWSERS.EDGE */ },
    { br: "Google Chrome", b: "Chrome" /* BROWSERS.CHROME */ },
    { br: "Opera", b: "Opera" /* BROWSERS.OPERA */ }
];
function _userAgentContainsString(searchString, userAgent) {
    return userAgent.indexOf(searchString) > -1;
}
function _getBrandVersion(match, brands) {
    for (var lp = 0; lp < brands.length; lp++) {
        if (match == brands[lp].brand) {
            return brands[lp].version;
        }
    }
    return null;
}
function _getBrowserName(userAgent) {
    if (userAgent) {
        for (var lp = 0; lp < USER_AGENTS.length; lp++) {
            var ua = USER_AGENTS[lp].ua;
            if (_userAgentContainsString(ua, userAgent)) {
                return USER_AGENTS[lp].b;
            }
        }
    }
    return UNKNOWN;
}
function _getBrowserVersion(userAgent, browserName) {
    if (browserName === "MSIE" /* BROWSERS.MSIE */) {
        return _getIeVersion(userAgent);
    }
    return _getOtherVersion(browserName, userAgent);
}
function _getIeVersion(userAgent) {
    var classicIeVersionMatches = userAgent.match(new RegExp("MSIE" /* BROWSERS.MSIE */ + " " + REGEX_VERSION));
    if (classicIeVersionMatches) {
        return classicIeVersionMatches[1];
    }
    var ieVersionMatches = userAgent.match(new RegExp("rv:" + REGEX_VERSION));
    if (ieVersionMatches) {
        return ieVersionMatches[1];
    }
}
function _getOtherVersion(browserString, userAgent) {
    if (browserString === "Safari" /* BROWSERS.SAFARI */) {
        browserString = "Version";
    }
    else if (browserString === "Edge" /* BROWSERS.EDGE */) {
        if (_userAgentContainsString(EDGE_CHROMIUM, userAgent)) {
            browserString = "Edg";
        }
    }
    var matches = userAgent.match(new RegExp(browserString + "/" + REGEX_VERSION));
    if (matches) {
        return matches[1];
    }
    if (browserString === "Opera" /* BROWSERS.OPERA */) {
        matches = userAgent.match(new RegExp("OPR/" + REGEX_VERSION));
        if (matches) {
            return matches[1];
        }
    }
    return UNKNOWN;
}
/**
* Get Screen resolution
* @returns {ScreenResolution} - Screen resolution
*/
function _getScreenResolution() {
    var screenRes = { h: 0, w: 0 };
    var win = getWindow();
    if (win && win.screen) {
        screenRes.h = screen.height;
        screenRes.w = screen.width;
    }
    return screenRes;
}
function _getUserConsent() {
    return this.getUserConsent();
}
var Web = /** @class */ (function () {
    function Web(propertiesConfig, core, unloadHookContainer) {
        var _cookieMgr = safeGetCookieMgr(core);
        var _propertiesConfig = propertiesConfig || {};
        var _userAgent = null;
        var _userAgentBrands = null;
        var _userBrowser = null; // save user defined browser. If defined, this value will overwrite dynamic config values
        var _userBrowserVer = null; // save user defined browser ver. If defined, this value will overwrite dynamic config values
        var _browser = null;
        var _browserVer = null;
        var _gpcDataSharingOption = null;
        dynamicProto(Web, this, function (_self) {
            _populateDefaults(propertiesConfig);
            // Add the domain
            var windowLocation = getLocation();
            if (windowLocation) {
                var domain = windowLocation.hostname;
                if (domain) {
                    _self.domain = windowLocation.protocol === "file:" ? "local" : domain;
                }
            }
            var screenRes = _getScreenResolution();
            _self.screenRes = screenRes.w + "X" + screenRes.h;
            _self.getUserConsent = function () {
                return _propertiesConfig.userConsented || (getCookieValue(_cookieMgr, _propertiesConfig.userConsentCookieName || "MSCC") ? true : false);
            };
            /**
            *
            ** Function to retrieve user consent details.
            * @param callback - Callback function to get user consent details
            * @returns IUserContentDetails stringified object
            */
            _self.getUserConsentDetails = function () {
                var consentDetails = null;
                try {
                    var callback = _propertiesConfig.callback;
                    if (callback && callback.userConsentDetails) {
                        var result = callback.userConsentDetails();
                        if (result) {
                            if (_propertiesConfig.disableConsentDetailsSanitize) {
                                consentDetails = result;
                            }
                            else {
                                consentDetails = {};
                            }
                            // Apply default values if missing
                            for (var lp = 0; lp < USER_CONSENT_DETAILS.length; lp++) {
                                var key = USER_CONSENT_DETAILS[lp];
                                consentDetails[key] = result[key] || false;
                            }
                        }
                    }
                    // Only set if the configuration was provided
                    if (_gpcDataSharingOption !== null) {
                        consentDetails = consentDetails || {};
                        consentDetails.GPC_DataSharingOptIn = !!_gpcDataSharingOption;
                    }
                    return consentDetails ? JSON.stringify(consentDetails) : null;
                }
                catch (e) {
                    // Unexpected - Just making sure we don't crash
                }
            };
            function _parseUserAgent(userAgent, userAgentBrands) {
                if (isArray(userAgentBrands)) {
                    try {
                        // Go through the ordered list of "known" brands and use the first matching value
                        for (var lp = 0; lp < BRANDS.length; lp++) {
                            var version = _getBrandVersion(BRANDS[lp].br, userAgentBrands);
                            if (version) {
                                _browser = BRANDS[lp].b;
                                _browserVer = version;
                                return;
                            }
                        }
                    }
                    catch (e) {
                        // Unexpected - Just making sure we don't crash
                    }
                }
                if (userAgent) {
                    var browserName = _getBrowserName(userAgent);
                    _browser = browserName;
                    _browserVer = _getBrowserVersion(userAgent, browserName);
                }
            }
            function _setBrowser(value) {
                _userBrowser = value;
            }
            function _setBrowserVer(value) {
                _userBrowserVer = value;
            }
            function _getBrowser() {
                return _userBrowser || _browser;
            }
            function _getBrowserVer() {
                return _userBrowserVer || _browserVer;
            }
            var _getGpcDataSharing = function () {
                return _gpcDataSharingOption;
            };
            var _setGpcDataSharing = function (value) {
                // Setting directly, rather than waiting for the onConfigChange so that the new value is available immediately
                _gpcDataSharingOption = isBoolean(value) ? value : null;
                // Also update the configuration so any listeners are also notified in the next JS cycle
                _propertiesConfig.gpcDataSharingOptIn = _gpcDataSharingOption;
            };
            function _populateDefaults(config) {
                // This function will be re-called whenever any referenced configuration is changed
                var unloadHook = onConfigChange(config, function () {
                    _propertiesConfig = config;
                    // if populateBrowserInfo is set to false, it will use previous values (so, it will not reset)
                    if (_propertiesConfig.populateBrowserInfo) {
                        var userAgent = _propertiesConfig.userAgent;
                        var userAgentBrands = (_propertiesConfig.userAgentData || {}).brands;
                        if (userAgent !== _userAgent || userAgentBrands !== _userAgentBrands) {
                            if (!userAgent || !userAgentBrands || userAgentBrands.length === 0) {
                                // One or more values not specified so try and derive from the navigator (if available)
                                var theNav = getNavigator();
                                if (theNav) {
                                    userAgent = userAgent || theNav.userAgent || "";
                                    userAgentBrands = userAgentBrands || (theNav.userAgentData || {}).brands;
                                }
                            }
                            _parseUserAgent(userAgent, userAgentBrands);
                            _userAgent = userAgent;
                            _userAgentBrands = userAgentBrands;
                        }
                    }
                    // Only set if the configuration was provided
                    _gpcDataSharingOption = isBoolean(_propertiesConfig.gpcDataSharingOptIn) ? _propertiesConfig.gpcDataSharingOptIn : null;
                });
                unloadHookContainer && unloadHookContainer.add(unloadHook);
            }
            // Remap this get userContext for this instance
            objDefineProps(_self, {
                "userConsent": { g: _self.getUserConsent },
                "browser": { s: _setBrowser, g: _getBrowser },
                "browserVer": { s: _setBrowserVer, g: _getBrowserVer },
                "gpcDataSharingOptIn": { g: _getGpcDataSharing, s: _setGpcDataSharing }
            });
        });
    }
// Removed Stub for Web.prototype.getUserConsent.
// Removed Stub for Web.prototype.getUserConsentDetails.
    /**
     * Static constructor, attempt to create accessors
     */
    Web._staticInit = (function () {
        // Dynamically create get/set property accessors
        //objDefineAccessors(Web.prototype, "userConsent", _getUserConsent);
        objDefine(Web.prototype, "userConsent", { g: _getUserConsent });
    })();
    return Web;
}());
export { Web };
//# sourceMappingURL=Web.js.map