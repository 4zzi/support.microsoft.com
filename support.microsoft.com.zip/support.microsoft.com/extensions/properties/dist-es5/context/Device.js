/*
 * 1DS JS SDK Properties plugin, 4.0.2
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
/**
* Device.ts
* @author Hector Hernandez (hectorh)
* @copyright Microsoft 2019
*/
var Device = /** @class */ (function () {
    function Device() {
    }
    return Device;
}());
export { Device };
//# sourceMappingURL=Device.js.map