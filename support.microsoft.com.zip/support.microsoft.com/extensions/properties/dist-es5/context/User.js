/*
 * 1DS JS SDK Properties plugin, 4.0.2
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
/**
* User.ts
* @author Hector Hernandez (hectorh)
* @copyright Microsoft 2019
*/
import dynamicProto from "@microsoft/dynamicproto-js";
import { getCookieValue, getISOString, isUndefined, newId, onConfigChange } from "@microsoft/1ds-core-js";
import { objDefine } from "@nevware21/ts-utils";
var strSetLocalId = "setLocalId";
function _getLocalId() {
    return this.getLocalId();
}
function _setLocalId(value) {
    this[strSetLocalId](value);
}
var User = /** @class */ (function () {
    function User(coreConfig, propertiesConfig, core, unloadHookContainer) {
        var _propertiesConfig;
        var _customLocalId;
        var _cookieMgr;
        dynamicProto(User, this, function (_self) {
            _populateDefaults(propertiesConfig);
            // Add user language
            if (typeof navigator !== "undefined") {
                var nav = navigator;
                _self.locale = nav.userLanguage || nav.language;
            }
            _self.getLocalId = function () {
                if (_customLocalId) {
                    return _customLocalId;
                }
                return _populateMuidFromCookie();
            };
            _self[strSetLocalId] = function (value) {
                _customLocalId = value;
            };
            function _populateMuidFromCookie() {
                // Only add default local ID is hash or drop config are not enabled
                if (!_propertiesConfig.hashIdentifiers && !_propertiesConfig.dropIdentifiers) {
                    var muidValue = getCookieValue(_cookieMgr, "MUID");
                    if (muidValue) {
                        _customLocalId = "t:" + muidValue;
                    }
                }
                return _customLocalId;
            }
            function _populateDefaults(config) {
                // This function will be re-called whenever any referenced configuration is changed
                var unloadHook = onConfigChange(config, function () {
                    _cookieMgr = core && core.getCookieMgr();
                    _propertiesConfig = config;
                    // reset it since this value is dependent on cookieMgr, config.hashIdentifiers and config.dropIdentifiers
                    _customLocalId = null;
                    if (_cookieMgr && _cookieMgr.isEnabled()) {
                        _populateMuidFromCookie();
                        if (_propertiesConfig.enableApplicationInsightsUser) {
                            // get userId or create new one if none exists
                            var aiUser = getCookieValue(_cookieMgr, User.userCookieName);
                            if (aiUser) {
                                var params = aiUser.split(User.cookieSeparator);
                                if (params.length > 0) {
                                    _self.id = params[0];
                                }
                            }
                            if (!_self.id) {
                                _self.id = newId((coreConfig && !isUndefined(coreConfig.idLength)) ? coreConfig.idLength : 22);
                                var acqStr = getISOString(new Date());
                                _self.accountAcquisitionDate = acqStr;
                                // without expiration, cookies expire at the end of the session
                                // set it to 365 days from now
                                // 365 * 24 * 60 * 60 * 1000 = 31536000
                                var newCookie = [_self.id, acqStr];
                                var cookieDomain = _propertiesConfig.cookieDomain ? _propertiesConfig.cookieDomain : undefined;
                                _cookieMgr.set(User.userCookieName, newCookie.join(User.cookieSeparator), 31536000, cookieDomain);
                            }
                        }
                    }
                });
                unloadHookContainer && unloadHookContainer.add(unloadHook);
            }
        });
    }
// Removed Stub for User.prototype.getLocalId.
// Removed Stub for User.prototype.setLocalId.
    User.cookieSeparator = "|";
    User.userCookieName = "ai_user";
    /**
     * Static constructor, attempt to create accessors
     */
    User._staticInit = (function () {
        // Dynamically create get/set property accessors
        objDefine(User.prototype, "localId", { g: _getLocalId, s: _setLocalId });
    })();
    return User;
}());
export { User };
//# sourceMappingURL=User.js.map