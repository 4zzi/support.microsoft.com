/*
 * 1DS JS SDK Properties plugin, 4.0.2
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
/**
* AITrace.ts
* @author Hector Hernandez (hectorh)
* @copyright Microsoft 2019
*/
import { generateW3CId, getLocation, onConfigChange } from "@microsoft/1ds-core-js";
var Trace = /** @class */ (function () {
    function Trace(propertiesConfig, id, parentId, name, unloadHookContainer) {
        var self = this;
        self.traceId = id || generateW3CId();
        var unloadHook = onConfigChange(propertiesConfig, function () {
            var _config = propertiesConfig;
            if (_config.enableDistributedTracing && !parentId) {
                // When dt is enabled, both the traceId and spanId are required
                parentId = generateW3CId().substring(0, 16);
            }
            self.parentId = self.parentId || parentId; // change parentId only if it was not set previously
            if (_config.enableApplicationInsightsTrace && !name) {
                var loc = getLocation();
                if (loc && loc.pathname) {
                    name = loc.pathname;
                }
            }
            self.name = self.name || name; // change name only if it was not set previously
        });
        unloadHookContainer && unloadHookContainer.add(unloadHook);
    }
    return Trace;
}());
export { Trace };
//# sourceMappingURL=Trace.js.map