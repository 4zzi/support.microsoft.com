/*
 * 1DS JS SDK Web Analytics plugin, 4.0.2
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
/**
* AutoCaptureHandler.ts
* @author Ram Thiru (ramthi) and Hector Hernandez (hectorh)
* @copyright Microsoft 2018
*/
import dynamicProto from "@microsoft/dynamicproto-js";
import { addPageHideEventListener, addPageUnloadEventListener, createUniqueNamespace, eventOff, eventOn, getDocument, getWindow, mergeEvtNamespace, removePageHideEventListener, removePageUnloadEventListener } from "@microsoft/1ds-core-js";
import { onDomLoaded } from "../DataCollector";
import { ActionType } from "../Enums";
import { _debounce, _getScrollOffset, _isKeyboardEnter, _isKeyboardSpace, _isLeftClick, _isMiddleClick, _isRightClick } from "../common/Utils";
var clickCaptureInputTypes = { BUTTON: true, CHECKBOX: true, RADIO: true, RESET: true, SUBMIT: true };
var AutoCaptureHandler = /** @class */ (function () {
    /**
    * @param _plugin - WebAnalytics plugin
    * @param _logger - Trace logger to log to console.
    */
    function AutoCaptureHandler(webAnalytics, diagLog) {
        var _this = this;
        var _plugin;
        var _logger;
        var _evtNamespace;
        var _clickAdded;
        var _scrollAdded;
        var _maxScrollAdded;
        var _resizeAdded;
        var _unloadAdded;
        var _domLoadedAdded;
        dynamicProto(AutoCaptureHandler, this, function (_self) {
            // Clears out all local values this is also used during teardown
            _initDefaults();
            // Assign the values that we want to use
            _plugin = webAnalytics;
            _logger = diagLog;
            _evtNamespace = mergeEvtNamespace(createUniqueNamespace("AutoCaptureHandler"), _plugin._evtNamespace);
            // Re-Exposing as protected properties
            _self._analyticsPlugin = _plugin;
            _self._traceLogger = _logger;
            _self.pageView = function () {
                _plugin && _plugin.capturePageView({ isAuto: true });
            };
            _self.onLoad = function () {
                if (_plugin && !_domLoadedAdded) {
                    onDomLoaded(function () {
                        _plugin && _plugin.capturePageViewPerformance({ isAuto: true });
                        _plugin && _plugin.captureContentUpdate({ isAuto: true, isDomComplete: true });
                    }, _evtNamespace);
                    _domLoadedAdded = true;
                }
            };
            // handle automatic event firing on user click
            _self.click = function () {
                if (!_clickAdded) {
                    var win = getWindow();
                    var doc = getDocument();
                    if (win && win.addEventListener) {
                        // IE9 onwards addEventListener is available, 'click' event captures mouse click. mousedown works on other browsers
                        var event = (navigator.appVersion.indexOf("MSIE") !== -1) ? "click" : "mousedown";
                        eventOn(win, event, _processClick, _evtNamespace);
                        eventOn(win, "keyup", _processClick, _evtNamespace);
                    }
                    else if (doc && doc.attachEvent) {
                        // IE8 and below doesn't have addEventListener so it will use attachEvent
                        // attaching to window does not work in IE8
                        eventOn(doc, "click", _processClick, _evtNamespace);
                        eventOn(doc, "keyup", _processClick, _evtNamespace);
                    }
                    _clickAdded = true;
                }
            };
            // handle automatic event firing on user scroll
            _self.scroll = function (debounceConfig) {
                if (!_scrollAdded) {
                    var processScroll = _debounce(
                    // on first call do nothing
                    null, 
                    // after debounce, send contentView with viewportOffset
                    function () {
                        _plugin && _plugin.captureContentUpdate({ isAuto: true, actionType: ActionType.SCROLL });
                    }, debounceConfig.scroll, _this);
                    eventOn(getWindow(), "scroll", processScroll, _evtNamespace);
                    _scrollAdded = true;
                }
            };
            // handle automatic event firing on user scroll
            _self.maxScroll = function (maxScroll) {
                if (!_maxScrollAdded) {
                    var getMaxScrollDepth = function () {
                        var currentScroll = _getScrollOffset();
                        maxScroll.v = maxScroll.v > currentScroll.v ? maxScroll.v : currentScroll.v;
                    };
                    eventOn(getWindow(), "scroll", getMaxScrollDepth, _evtNamespace);
                    _maxScrollAdded = true;
                }
            };
            // handle automatic event firing on user resize
            _self.resize = function (debounceConfig) {
                /// I wasn't able to repro the bug
                /// (https://microsoft.visualstudio.com/DefaultCollection/OSGS/_workitems/edit/7958464)
                /// until new content was loaded on the page and the resize
                /// rendering became slow. When resize happens, the page rendering
                /// time is longer than the resize debounce, and resize render
                /// happens in time > debounce, and so resize is acting like
                /// it's being done twice: once at the beginning of user resize,
                /// one at the end of browser render resize.
                if (!_resizeAdded) {
                    var processResize = _debounce(
                    // on first call, send resize contentUpdate
                    function () {
                        _plugin && _plugin.captureContentUpdate({ isAuto: true, actionType: ActionType.RESIZE });
                    }, 
                    // after debounce, do nothing
                    null, debounceConfig.resize, _this);
                    eventOn(getWindow(), "resize", processResize, _evtNamespace);
                    _resizeAdded = true;
                }
            };
            _self.onUnload = function () {
                function _doUnload() {
                    _plugin && _plugin.capturePageUnload({ isAuto: true });
                }
                if (!_unloadAdded) {
                    var coreConfig = ((_plugin || {}).core || {}).config;
                    var excludePageUnloadEvents = coreConfig.disablePageUnloadEvents;
                    addPageUnloadEventListener(_doUnload, excludePageUnloadEvents, _evtNamespace);
                    addPageHideEventListener(_doUnload, excludePageUnloadEvents, _evtNamespace);
                    _unloadAdded = true;
                }
            };
            _self.teardown = function (unloadCtx, unloadState) {
                eventOff(getWindow(), null, null, _evtNamespace);
                eventOff(getDocument(), null, null, _evtNamespace);
                removePageUnloadEventListener(null, _evtNamespace);
                removePageHideEventListener(null, _evtNamespace);
                _initDefaults();
            };
            _self._processClick = _processClick;
            function _processClick(clickEvent) {
                var clickCaptureElements = { A: true, BUTTON: true, AREA: true, INPUT: true };
                var win = getWindow();
                clickEvent = clickEvent || win.event; // IE 8 does not pass the event
                var element = clickEvent.srcElement || clickEvent.target;
                // populate overrideValues
                var overrideValues = {
                    isAuto: true,
                    clickCoordinateX: clickEvent.pageX,
                    clickCoordinateY: clickEvent.pageY
                };
                var isRightClick = _isRightClick(clickEvent);
                if (isRightClick) {
                    overrideValues.actionType = ActionType.CLICKRIGHT;
                }
                else if (_isLeftClick(clickEvent)) {
                    overrideValues.actionType = ActionType.CLICKLEFT;
                }
                else if (_isKeyboardEnter(clickEvent)) {
                    overrideValues.actionType = ActionType.KEYBOARDENTER;
                }
                else if (_isKeyboardSpace(clickEvent)) {
                    overrideValues.actionType = ActionType.KEYBOARDSPACE;
                }
                else if (_isMiddleClick(clickEvent)) {
                    overrideValues.actionType = ActionType.CLICKMIDDLE;
                }
                else {
                    return;
                }
                while (element && element.tagName) {
                    // control property will be available for <label> elements with 'for' attribute, only use it when is a
                    // valid JSLL capture element to avoid infinite loops
                    if (element.control && clickCaptureElements[element.control.tagName.toUpperCase()]) {
                        element = element.control;
                    }
                    if (!clickCaptureElements[element.tagName.toUpperCase()]) {
                        element = element.parentElement || element.parentNode;
                        continue;
                    }
                    else {
                        // Check allowed INPUT types
                        var sendEvent = element.tagName.toUpperCase() === "INPUT" ? clickCaptureInputTypes[element.type.toUpperCase()] : true;
                        if (sendEvent) {
                            _plugin && _plugin.capturePageAction(element, overrideValues, {}, isRightClick);
                        }
                        break;
                    }
                }
            }
            function _initDefaults() {
                _self._analyticsPlugin = null;
                _self._traceLogger = null;
                _plugin = null;
                _logger = null;
                _evtNamespace = null;
                _scrollAdded = false;
                _maxScrollAdded = false;
                _resizeAdded = false;
                _unloadAdded = false;
                _domLoadedAdded = false;
            }
        });
    }
// Removed Stub for AutoCaptureHandler.prototype.pageView.
// Removed Stub for AutoCaptureHandler.prototype.onLoad.
    // handle automatic event firing on user click
// Removed Stub for AutoCaptureHandler.prototype.click.
    // handle automatic event firing on user scroll
// Removed Stub for AutoCaptureHandler.prototype.scroll.
    // handle automatic event firing on user scroll
// Removed Stub for AutoCaptureHandler.prototype.maxScroll.
    // handle automatic event firing on user resize
// Removed Stub for AutoCaptureHandler.prototype.resize.
// Removed Stub for AutoCaptureHandler.prototype.onUnload.
// Removed Stub for AutoCaptureHandler.prototype.teardown.
// Removed Stub for AutoCaptureHandler.prototype._processClick.
    // This is a workaround for an IE8 bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    // this will be removed when ES3 support is dropped.
    AutoCaptureHandler.__ieDyn=1;

    return AutoCaptureHandler;
}());
export { AutoCaptureHandler };
//# sourceMappingURL=AutoCaptureHandler.js.map