// Copyright (C) Microsoft Corporation. All rights reserved.

import { isUserAuthenticated } from "../Common/Helpers";
import { SilentSignInProperties } from '../Common/AuthenticationTypes';
import type { IOnAfterGetRememberedAccountsEvent, MeControlNamespace, AccountType } from '@mecontrol/public-api';
import type { ApplicationInsights, Behavior, IContentUpdateOverrideValues } from "@microsoft/1ds-analytics-web-js";
import { CaptureContentEventProperties, LogContentUpdateEvent, BehaviorType } from '../Common/Logging';
import { setQueryString } from "../Common/QueryStringHelpers";

declare global {
	interface Window {
		analytics?: ApplicationInsights;
		MeControl: MeControlNamespace;
		MeControlAccountType: typeof AccountType;
		oneDS: {
			Behavior: typeof Behavior;
		};
	}
}

const CALLOUT_EVENT_NAME = "displayTeachingCallout";
let rememberedAccountsCount: number = -1;

function handleSilentSignInAttempted(resolve: (value?: SilentSignInProperties) => void, reject: (reason?: SilentSignInProperties) => void, e: CustomEvent) {
	let authType: string = e.detail['authType'];
	if (isUserAuthenticated(authType)) {
		resolve(e.detail);
	}
	else {
		reject(e.detail); // Difference is, within e.detail, "account" will be different for both signout and signed in state
	}
}

function handleAfterGetRememberedAccounts(resolve: (value?: string) => void, reject: (reason?: string) => void, event: IOnAfterGetRememberedAccountsEvent) {
	let countRememberedAccounts = event?.detail?.rememberedAccounts?.length ?? -1;
	rememberedAccountsCount = countRememberedAccounts;

	let preferredUserName = "";

	if (countRememberedAccounts === -1) {
		reject('0');
	}
	else if (countRememberedAccounts === 0) {
		var rememberedAccountsAuthState: IContentUpdateOverrideValues = {
			isAuto: false,
			content: { contentId: 'noRememberedAccounts' },
			behavior: window.oneDS.Behavior.OTHER
		};

		window.analytics?.captureContentUpdate(rememberedAccountsAuthState);
		resolve('');

	}
	else if (countRememberedAccounts >= 1) {

		let aadNameList: string[] = new Array();
		let msaNameList: string[] = new Array();

		event.detail.rememberedAccounts.forEach(function (rememberedAccount) {
			if (rememberedAccount['type'] === window.MeControlAccountType.AAD) {
				aadNameList.push(rememberedAccount['memberName']);
			}
			else if (rememberedAccount['type'] === window.MeControlAccountType.MSA || rememberedAccount['type'] === window.MeControlAccountType.MSA_FED) {
				msaNameList.push(rememberedAccount['memberName']);
			}
		});

		let aadAccountsCount = aadNameList.length;
		let msaAccountsCount = msaNameList.length;

		if (aadAccountsCount >= 1) {
			for (var i = 0; i < aadAccountsCount; i++) {
				if (aadNameList[i].endsWith('microsoft.com')) {
					preferredUserName = aadNameList[i];
					break;
				}
			}
			if (preferredUserName === '') {
				let aadRandomIndex: number = Math.random() * aadNameList.length;
				preferredUserName = aadNameList[Math.floor(aadRandomIndex)];
			}
		}
		else if (msaAccountsCount >= 1) {
			let msaRandomIndex: number = Math.random() * msaNameList.length;
			preferredUserName = msaNameList[Math.floor(msaRandomIndex)];
		}

		var authStateContentId = (aadAccountsCount >= 1 && msaAccountsCount >= 1) ? 'mixedAuthType'
			: (aadAccountsCount >= 1 ? 'aadAuthType' : (msaAccountsCount >= 1 ? 'msaAuthType' : ''));

		var rememberedAccountsAuthState: IContentUpdateOverrideValues = {
			isAuto: false,
			content: { contentId: authStateContentId },
			behavior: window.oneDS.Behavior.OTHER
		};

		window.analytics?.captureContentUpdate(rememberedAccountsAuthState);

		resolve(preferredUserName || '');
	}
}
function silentSignInAttempt(): Promise<SilentSignInProperties> {
	return new Promise((resolve, reject) => {
		window.document.addEventListener('silentSignInAttempted', (e: CustomEvent) => handleSilentSignInAttempted(resolve, reject, e), {once : true});
	});
}

function handleRememberedAccounts(): Promise<string> {
	return new Promise((resolve, reject) => {
		window.MeControl.API.addEventListener('aftergetrememberedaccounts', (e: IOnAfterGetRememberedAccountsEvent) => handleAfterGetRememberedAccounts(resolve, reject, e));
	});
}

function logSilentSignInFailedLoginHint(accountCount: number) {
	var captureEvent: CaptureContentEventProperties = {
		isManual: true,
		actionType: 'A',
		content: {
			contentId: 'silentSignInFailedLoginHint',
			rememberedAccountsCount: accountCount == 0 ? 'noAccount' :
				(accountCount == 1 ? 'singleAccount' :
					(accountCount > 1 ? 'multiAccount' : 'rememberedAccountAPIError'))
		}
	};
	LogContentUpdateEvent(captureEvent, BehaviorType.Impression);
}

function logSilentSignInIsComplete(signInProperties: SilentSignInProperties) {
	window.silentSigninProgress = false;
	const eventType = 'silentSignInComplete';

	const silentSignInCompleteEvent = new CustomEvent(eventType, {
		detail: { ...signInProperties },
		bubbles: true,
		cancelable: false
	});

	window.document.dispatchEvent(silentSignInCompleteEvent);
}

function DispatchTeachingCalloutEvent(messageState: string, silentSignInProperties?: SilentSignInProperties) {
	const displayName = silentSignInProperties?.account?.firstName;
	const signInResultWithCalloutEvent = new CustomEvent(CALLOUT_EVENT_NAME, {
		detail: {
			displayMessageState: messageState,
			displayName
		}
	});

	window.top.document.dispatchEvent(signInResultWithCalloutEvent);
}

export interface IHandlerSilentSignInAttempted {
	silentSignInAttemptPromise: Promise<SilentSignInProperties>;
	handleRememberedAccountsPromise: Promise<string>;

	handleAllSilentSignIn(): Promise<void>;
}

export class HandlerSilentSignInAttempted implements IHandlerSilentSignInAttempted {
	silentSignInAttemptPromise: Promise<SilentSignInProperties>;
	handleRememberedAccountsPromise: Promise<string>;

	constructor() {
		this.silentSignInAttemptPromise = silentSignInAttempt();
		this.handleRememberedAccountsPromise = handleRememberedAccounts();
	}

	async handleAllSilentSignIn(): Promise<void> {
		let silentSignInProperties: SilentSignInProperties;
		let preferredUserName: string;

		try {
			silentSignInProperties = await this.silentSignInAttemptPromise as SilentSignInProperties;
			logSilentSignInIsComplete(silentSignInProperties);
			return;
		}
		catch (silentSignPropertiesNoAccounts) {
			silentSignInProperties = silentSignPropertiesNoAccounts;
		}

		try {
			preferredUserName = await this.handleRememberedAccountsPromise as string;
			if (preferredUserName === '') {
				throw new Error(preferredUserName);
			}
		}
		catch (error) {
			DispatchTeachingCalloutEvent('noAccounts');
			logSilentSignInFailedLoginHint(rememberedAccountsCount);
			logSilentSignInIsComplete(silentSignInProperties);
			return;
		}

		const silentSignInIframe = window.document.getElementById('iframeOP') as HTMLIFrameElement;

		if (silentSignInIframe.src.includes('login_hint')) {
			return;
		}

		silentSignInIframe.setAttribute('isduplicateattempt', 'true');

		// Call to Identity initiated with login_hint.
		silentSignInIframe.src = setQueryString("login_hint", preferredUserName, silentSignInIframe.src).toString();

		try {
			silentSignInProperties = await silentSignInAttempt() as SilentSignInProperties;
			DispatchTeachingCalloutEvent('multipleSignInSuccess', silentSignInProperties);
		}
		catch (silentSignPropertiesNoAccounts) {
			silentSignInProperties = silentSignPropertiesNoAccounts;
			logSilentSignInFailedLoginHint(rememberedAccountsCount);
			DispatchTeachingCalloutEvent('multipleSignInFail');
		}
		finally {
			logSilentSignInIsComplete(silentSignInProperties);
		}
	}
}
