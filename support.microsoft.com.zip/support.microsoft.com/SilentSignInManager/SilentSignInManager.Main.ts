// Copyright (C) Microsoft Corporation. All rights reserved.

import { IHandlerSilentSignInAttempted, HandlerSilentSignInAttempted } from './SilentSignInManager';

declare global {
	interface Window {
		manageSilentSignIn:  IHandlerSilentSignInAttempted
	}
}

//Webpack will tree shake this function unless it is used somewhere in the source files.

window.manageSilentSignIn = new HandlerSilentSignInAttempted();
