// Copyright (C) Microsoft. All rights reserved.

import { SelectableContentOptionsController } from './SelectableContentOptionsController';

/**
 * Initializes all selectable content options controllers on the page.
 * @returns void
 */
export function initializeSelectableContentOptions(): void {
	const containers = document.querySelectorAll<HTMLDivElement>('.selectable-content-options__content-container');
	containers.forEach((container: HTMLDivElement) => {
		new SelectableContentOptionsController(container);
	});
}
