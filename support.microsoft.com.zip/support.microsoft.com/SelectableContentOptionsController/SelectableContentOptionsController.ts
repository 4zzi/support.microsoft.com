/**
 * Class to control the seletable (dropdown) content options.
 */
export class SelectableContentOptionsController {
	private container: HTMLElement;
	private selectElement: HTMLSelectElement | null;
	private static selectElementSelector: string = '.selectable-content-options__element';
	private optionsContainer: HTMLElement | null;
	private static optionsContainerSelector: string = '.selectable-content-options__options-container';
	private optionContents: HTMLCollectionOf<Element>;
	private static optionContentsClass: string = 'selectable-content-options__option-content';

	/**
	 * Creates an instance of DropdownContentController.
	 * @param container - The container element for the dropdown.
	 */
	constructor(container: HTMLDivElement) {
		this.container = container;
		this.selectElement = this.getSelectElement();
		this.optionsContainer = this.getOptionsContainer();
		this.optionContents = this.getOptionContents();

		if (!this.selectElement || !this.optionsContainer || !this.optionContents) {
			throw new Error("SelectableContentOptionsController: Missing required elements");
		}

		this.init();
	}

	/**
	 * Initializes the dropdown content controller.
	 */
	private init (this: SelectableContentOptionsController) {
		this.selectElement.addEventListener('change', () => this.displaySelectedContent());
		this.displaySelectedContent();
	}

	/**
	 * Gets the select element within the container.
	 * @returns The select element or null if not found.
	 */
	private getSelectElement(this: SelectableContentOptionsController): HTMLSelectElement | null {
		return this.container.querySelector<HTMLSelectElement>(SelectableContentOptionsController.selectElementSelector);
	}

	/**
	 * Gets the options container element within the container.
	 * @returns The options container element or null if not found.
	 */
	private getOptionsContainer(this: SelectableContentOptionsController): HTMLDivElement | null {
		return this.container.querySelector<HTMLDivElement>(SelectableContentOptionsController.optionsContainerSelector);
	}

	/**
	 * Gets the option contents within the options container.
	 * @returns A collection of option content elements.
	 */
	private getOptionContents(this: SelectableContentOptionsController): HTMLCollectionOf<Element> {
		return this.optionsContainer?.getElementsByClassName(SelectableContentOptionsController.optionContentsClass);
	}

	/**
	 * Displays the content corresponding to the selected option.
	 */
	private displaySelectedContent(this: SelectableContentOptionsController): void {
		const selectedValue = this.getSelectedValue();
		if (!selectedValue) return;

		this.hideAllOptionContents();
		this.showSelectedOptionContent(selectedValue);
	}

	/**
	 * Gets the value of the selected option.
	 * @returns The value of the selected option or null if no select element.
	 */
	private getSelectedValue(this: SelectableContentOptionsController): string | null {
		return this.selectElement ? this.selectElement.value : null;
	}

	/**
	 * Hides all option content elements.
	 */
	private hideAllOptionContents(this: SelectableContentOptionsController): void {
		Array.from(this.optionContents).forEach((div) => {
			if (div instanceof HTMLElement) {
				div.classList.add('ocHidden');
			}
		});
	}

	/**
	 * Shows the content corresponding to the selected option.
	 * @param selectedValue - The value of the selected option.
	 */
	private showSelectedOptionContent(this: SelectableContentOptionsController, selectedValue: string): void {
		if (!this.optionsContainer) return;

		const selectedDiv = this.optionsContainer.querySelector(`#${selectedValue}`);
		if (selectedDiv && selectedDiv instanceof HTMLElement) {
			selectedDiv.classList.remove('ocHidden');
		} else {
			console.warn(`No content found for the selected option: ${selectedValue}`);
		}
	}
}
