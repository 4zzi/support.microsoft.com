import { Reducer, combineReducers } from 'redux';
import { IMeControlDisplayMode } from '@mecontrol/common';
import { current } from './current';
import { breakpoint } from './breakpoint';

/** Reducer for the ui part of the state */
export const displayMode: Reducer<IMeControlDisplayMode> = combineReducers({
    current,
    breakpoint
});
