import { Reducer, combineReducers } from 'redux';
import { IMeControlAccounts } from '@mecontrol/common';
import { byId } from './byId';
import { allIds } from './allIds';
import { currentId } from './currentId';

/** Reducer for the accounts part of the state */
export const accounts: Reducer<IMeControlAccounts> = combineReducers({
    byId,
    allIds,
    currentId
});
