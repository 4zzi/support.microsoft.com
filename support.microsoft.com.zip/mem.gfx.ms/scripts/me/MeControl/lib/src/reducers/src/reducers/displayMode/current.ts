import { Reducer } from 'redux';
import { RuntimeDisplayMode } from '@mecontrol/public-api';
import { AllActions, ActionTypes } from '@mecontrol/common';

export const current: Reducer<RuntimeDisplayMode> = (state = RuntimeDisplayMode.Auto, action: AllActions) => {
    switch (action.type) {
        case ActionTypes.SET_DISPLAY_MODE:
            return action.payload.mode;
        default:
            return state;
    }
};
