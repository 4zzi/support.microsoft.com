import { Reducer, combineReducers } from 'redux';
import { IMeControlAppState } from '@mecontrol/common';
import { accounts } from './accounts';
import { commands } from './commands';
import { displayMode } from './displayMode';
import { picturesStatus } from './picturesStatus';
import { theme } from './theme';
import { presenceConfig } from './presenceConfig';
import { headerTheme } from './headerTheme';

export const rootReducer: Reducer<IMeControlAppState> = combineReducers({
    accounts,
    commands,
    displayMode,
    picturesStatus,
    theme,
    headerTheme,
    presenceConfig
});
