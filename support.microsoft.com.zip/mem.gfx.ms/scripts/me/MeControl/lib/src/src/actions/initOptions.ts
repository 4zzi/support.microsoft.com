import { ActionTypes, InitOptionsAction, IValidatedMeControlConfiguration } from '@mecontrol/common';

export function initOptions(options: IValidatedMeControlConfiguration): InitOptionsAction {
    return {
        type: ActionTypes.INIT_OPTIONS,
        payload: {
            options
        }
    };
}
