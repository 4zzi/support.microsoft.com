import { h, FunctionalComponent } from 'preact';

interface IScreenReaderTextProps {
    children: string;
}

export const ScreenReaderText: FunctionalComponent<IScreenReaderTextProps> = props =>
    <span class='mectrl_screen_reader_text'>
        {props.children}
    </span>;
