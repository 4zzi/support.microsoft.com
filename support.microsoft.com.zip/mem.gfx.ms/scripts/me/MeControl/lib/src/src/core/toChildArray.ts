import { VNode } from "preact";

// Dumb hack to work-around Preact types. The next major version of Preact
// (Preact X) will fix this by introducing a new function `toChildArray` whose
// signature is similar to the following. So hacking around the broken types
// for now by creating a similar function.
//
// P.S. In Preact X, this function will do something meaningful, unlike the
// hack below.
export function toChildArray(children: any): VNode[] {
    return children;
}
