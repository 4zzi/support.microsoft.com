
const ieOldRegex = /MSIE \d+\.\d+/;
const ie11Regex = /Trident\/\d+\.\d+/;

/**
 * Determine if the current browser is IE or not
 * Uses UserAgent string to make determination
 */
export function isIE(userAgent: string): boolean {
    if (userAgent) {
        if (ieOldRegex.test(userAgent) || ie11Regex.test(userAgent)) {
            return true;
        }
    }

    return false;
}
