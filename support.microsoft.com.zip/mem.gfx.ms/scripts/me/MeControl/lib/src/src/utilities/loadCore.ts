import { meImport } from '@mecontrol/web-inline';
import { onLoadUntilUrgent } from './onLoadUntilUrgent';

export function loadCore(): Promise<any> {
    return onLoadUntilUrgent().then(() => meImport("meCore"));
}
